# modelcomponents/carrier_mediated.py
from Region import Region

class CarrierMediated:
    def __init__(self, cell, medium,Naconcell,Kconcell,Aconcell,Naconmed,Kconmed,Aconmed,i_18):
        self.cell = cell
        self.medium = medium
        self.cell = Region()
        self.medium = Region()
        self.defaultPermeability_Na = 0.0
        self.defaultPermeability_K = 0.0
        self.permeability_Na = self.defaultPermeability_Na
        self.permeability_K = self.defaultPermeability_K
        self.Na_cell_con = Naconcell
        self.K_cell_con = Kconcell
        self.A_cell_con = Aconcell
        self.Na_med_con = Naconmed
        self.K_med_con = Kconmed
        self.A_med_con = Aconmed
        self.flux_Na = 0.0
        self.flux_K = 0.0
        self.i_18 = i_18

    def compute_permeabilities(self):


        # Compute denominator for Na permeability
        denominator_Na = self.Na_cell_con * self.A_cell_con - self.Na_med_con * self.A_med_con
        if denominator_Na != 0:
            self.permeability_Na = abs(self.get_flux_Na() / denominator_Na)
        else:
            # Handle zero denominator case (set to a default value or raise an error)
            self.permeability_Na = 0  # or raise ValueError("Division by zero in Na permeability calculation.")

        # Compute denominator for K permeability
        denominator_K = self.K_cell_con * self.A_cell_con - self.K_med_con * self.A_med_con
        if denominator_K != 0:
            self.permeability_K = abs(self.get_flux_K() / denominator_K)
        else:
            # Handle zero denominator case (set to a default value or raise an error)
            self.permeability_K = 0  # or raise ValueError("Division by zero in K permeability calculation.")

    def compute_flux(self):
        # Define a small threshold value to avoid floating-point precision issues
        epsilon = 1e-10

        if abs(self.i_18) > epsilon:
            self.flux_Na = -(self.permeability_Na / self.i_18) * (
                    self.Na_cell_con * self.A_cell_con - self.Na_med_con * self.A_med_con)
            self.flux_K = -(self.permeability_K / self.i_18) * (
                    self.K_cell_con * self.A_cell_con - self.K_med_con * self.A_med_con)
        else:
            # Handle the case when i_18 is very close to zero or zero
            self.flux_Na = 0
            self.flux_K = 0


    def get_flux_Na(self):
        return self.flux_Na

    def set_flux_Na(self, flux_Na):
        self.flux_Na = flux_Na

    def get_flux_K(self):
        return self.flux_K

    def set_flux_K(self, flux_K):
        self.flux_K = flux_K

    def set_default_permeability_Na(self, default_Na):
        self.defaultPermeability_Na = default_Na
        self.permeability_Na = default_Na

    def set_default_permeability_K(self, default_K):
        self.defaultPermeability_K = default_K
        self.permeability_K = default_K

    def get_default_permeability_Na(self):
        return self.defaultPermeability_Na

    def get_default_permeability_K(self):
        return self.defaultPermeability_K

    def get_permeability_Na(self):
        return self.permeability_Na

    def set_permeability_Na(self, permeability_Na):
        self.permeability_Na = permeability_Na

    def get_permeability_K(self):
        return self.permeability_K

    def set_permeability_K(self, permeability_K):
        self.permeability_K = permeability_K
