from dataclasses import dataclass, field
from typing import Optional, Dict, Any


class Piezo:
    def __init__(self):

        self.start_time = None
        self.duration = None
        self.recovery = None
        self.cycles = None
        #self.pkg = 0.0
        #self.pnag = 0.0
        #self.pcag = 70.0
        #self.pag = 50.0
        #self.pmca = 0.0
        #self.piezo_fraction = 0.9
        #self.piezo_js = 1.0
        self.restore_medium = True
        self.set_restore_hepes_na(10.0)
        #self.restore_hepes_na = 10.0
        self.set_restore_ph(7.4)
        #self.restore_ph = 7.4
        self.set_restore_na(145.5048)
        self.set_restore_k(5.0)
        #self.restore_k = 5.0
        self.set_restore_mg(0.2)
        #self.restore_mg = 0.2
        self.set_restore_ca(1.0)
        #self.restore_ca = 1.0
        #self.old_if = None
        #self.i_f = 1.0e-5
        self.old_pkg = None
        self.old_pnag = None
        self.old_pcag = None
        self.old_pag = None
        self.old_pmca = None
        self.old_cycles = None

    # Getter and setter methods
    def get_restore_hepes_na(self):
        return self.restore_hepes_na

    def set_restore_hepes_na(self, value):
        self.restore_hepes_na = value

    def get_restore_ph(self):
        return self.restore_ph

    def set_restore_ph(self, value):
        self.restore_ph = value

    def get_restore_na(self):
        return self.restore_na

    def set_restore_na(self, value):
        self.restore_na = value

    def get_restore_k(self):
        return self.restore_k

    def set_restore_k(self, value):
        self.restore_k = value

    def get_restore_mg(self):
        return self.restore_mg

    def set_restore_mg(self, value):
        self.restore_mg = value

    def get_restore_ca(self):
        return self.restore_ca

    def set_restore_ca(self, value):
        self.restore_ca = value

    def set_restore_medium(self, value):
        self.restore_medium = value

    def get_restore_medium(self):
        return self.restore_medium

    def get_piezo_js(self):
        return self.piezo_js

    def set_piezo_js(self, value):
        self.piezo_js = value

    def get_pkg(self):
        return self.pkg

    def set_pkg(self, value):
        self.pkg = value

    def get_pnag(self):
        return self.pnag

    def set_pnag(self, value):
        self.pnag = value

    def get_pcag(self):
        return self.pcag

    def set_pcag(self, value):
        self.pcag = value

    def get_pag(self):
        return self.pag

    def set_pag(self, value):
        self.pag = value

    def get_pmca(self):
        return self.pmca

    def set_pmca(self, value):
        self.pmca = value

    def get_cycles(self):
        return self.cycles

    def set_cycles(self, value):
        self.cycles = value

    def get_recovery(self):
        return self.recovery

    def set_recovery(self, value):
        self.recovery = value

    def get_start_time(self):
        return self.start_time

    def get_duration(self):
        return self.duration

    def get_i_f(self):
        return self.i_f

    def set_i_f(self, value):
        self.i_f = value

    def get_old_pmca(self):
        return self.old_pmca

    def set_old_pmca(self, value):
        self.old_pmca = value

    def get_old_pag(self):
        return self.old_pag

    def set_old_pag(self, value):
        self.old_pag = value

    def get_old_pcag(self):
        return self.old_pcag

    def set_old_pcag(self, value):
        self.old_pcag = value

    def set_start_time(self, value):
        self.start_time = value

    def set_duration(self, value):
        self.duration = value

    def set_old_if(self, value):
        self.old_if = value

    def get_old_if(self):
        return self.old_if

    def set_old_pkg(self, value):
        self.old_pkg = value

    def get_old_pkg(self):
        return self.old_pkg

    def set_old_pnag(self, value):
        self.old_pnag = value

    def get_old_pnag(self):
        return self.old_pnag

    def set_old_cycles(self, value):
        self.old_cycles = value

    def get_old_cycles(self):
        return self.old_cycles

    def get_piezo_fraction(self):
        return self.piezo_fraction

    def set_piezo_fraction(self, value):
        self.piezo_fraction = value

    #def update_piezo_state(self, flux_na: float, flux_ca: float) -> None:
     #   self.old_if = self.i_f
      #  self.old_pkg = self.pkg
       # self.old_pnag = self.pnag
        #self.old_pcag = self.pcag
        #self.old_pag = self.pag
        #self.old_pmca = self.pmca
        #self.old_cycles = self.cycles

        #self.pkg += flux_na * 0.01
        #self.pnag += flux_ca * 0.01
        # Additional updates can be added here based on model requirements
