import math
from Region import Region

class NaPump:
    def __init__(self, temperature: float, cell: Region, medium: Region):
        self.temperature = temperature
        self.cell = cell
        self.medium = medium
        self.cell=Region()
        self.medium=Region()
        self.P_1 = 0.0
        self.default_P_1 = 0.0
        self.P_2 = 0.0
        self.Na_to_K = 1.5
        self.cell = cell
        self.medium = medium
        self.flux_fwd = -2.61
        self.flux_rev = 0.0015
        self.set_flux_net()
        self.set_flux_K()
        self.total_flux = self.flux_net + self.flux_K
        self.I_17 = 0.0
        self.B_1 = 0.2
        self.B_2 = 18.0
        self.B_3 = 0.1
        self.B_4 = 8.3
        self.mgnap = 0.0
        self.phnap = 0.0
        self.I_3 = 0.0
        self.I_6 = 0.0
        self.I_9 = 0.0
        self.I_11 = 0.0
        self.q10_active = 0.0
        self.set_q10_active(2.0)
        self.mgnapk = 0.05
        self.mgnapik = 4.0
        self.I_77 = 7.216
        self.I_78 = 0.4

    def set_q10_active(self, q10_active):
        self.q10_active = q10_active

    def compute_I(self) -> None:
        I_1 = self.B_1 * (1.0 + self.cell.K.getConcentration() / self.B_4)
        I_2 = self.cell.Na.getConcentration() / (self.cell.Na.getConcentration() + I_1)
        self.I_3 = I_2 ** 3
        I_4 = self.B_3 * (1.0 + self.medium.Na.getConcentration() / self.B_2)
        I_5 = self.medium.K.getConcentration() / (self.medium.K.getConcentration() + I_4)
        self.I_6 = I_5 ** 2
        I_7 = self.B_4 * (1.0 + self.cell.Na.getConcentration() / self.B_1)
        I_8 = self.cell.K.getConcentration() / (self.cell.K.getConcentration() + I_7)
        self.I_9 = I_8 ** 2
        I_10 = self.medium.Na.getConcentration() / (self.medium.Na.getConcentration() + self.B_2 * (1.0 + self.medium.K.getConcentration() / self.B_3))
        self.I_11 = I_10 ** 3
        self.I_17 = math.exp((37.0 - self.temperature) / 10.0 * math.log(self.q10_active))

    def compute_permeabilities(self) -> None:
        self.compute_I()

        self.compute_mgnap()
        self.compute_phnap()

        if self.mgnap != 0:
            self.set_default_P_1(abs(self.flux_fwd / self.mgnap * self.phnap * self.I_3 * self.I_6))
        else:
            # Handle the case where mgnap is zero
            print("Warning: mgnap is zero, cannot compute set_default_P_1")
            self.set_default_P_1(0)  # Or set to some default value or handle as needed

        if self.mgnap != 0:
            self.set_P_2(abs(self.flux_rev / self.mgnap * self.phnap * self.I_9 * self.I_11))
        else:
            # Handle the case where mgnap is zero
            print("Warning: mgnap is zero, cannot compute set_P_2")
            self.set_P_2(0)  # Or set to some default value or handle as needed

    def set_default_P_1(self, p_1: float) -> None:
        self.default_P_1 = p_1
        self.set_P_1(p_1)

    def get_default_P_1(self) -> float:
        return self.default_P_1

    def compute_mgnap(self) -> None:

        self.mgnap = (self.cell.Mgf.getConcentration() / (self.mgnapk + self.cell.Mgf.getConcentration()) * self.mgnapik / (self.mgnapik + self.cell.Mgf.getConcentration()))


    def compute_phnap(self) -> None:
        self.phnap = math.exp(-((self.cell.getpH() - self.I_77) / self.I_78) ** 2)

    def compute_flux(self) -> None:
        self.compute_I()
        self.compute_mgnap()
        self.compute_phnap()
        self.flux_fwd = -(self.P_1 / self.I_17) * self.mgnap * self.phnap * self.I_3 * self.I_6
        self.flux_rev = self.P_2 / self.I_17 * self.mgnap * self.phnap * self.I_9 * self.I_11
        self.set_flux_net()
        self.set_flux_K()
        self.total_flux = self.flux_net + self.flux_K

    def set_flux_fwd(self, f: float) -> None:
        self.flux_fwd = f

    def get_flux_fwd(self) -> float:
        return self.flux_fwd

    def set_flux_rev(self, f: float) -> None:
        self.flux_rev = f

    def get_flux_rev(self) -> float:
        return self.flux_rev

    def get_i_17(self) -> float:
        return self.I_17

    def get_flux_net(self) -> float:
        return self.flux_net

    def set_flux_net(self) -> None:
        self.flux_net = self.flux_fwd + self.flux_rev

    def get_flux_K(self) -> float:
        return self.flux_K

    def set_flux_K(self) -> None:
        self.flux_K = -self.flux_net / self.Na_to_K

    def get_P_1(self) -> float:
        return self.P_1

    def set_P_1(self, p_1: float) -> None:
        self.P_1 = p_1

    def get_P_2(self) -> float:
        return self.P_2

    def set_P_2(self, p_2: float) -> None:
        self.P_2 = p_2

    def get_total_flux(self) -> float:
        return self.total_flux

    def set_total_flux(self, total_flux: float) -> None:
        self.total_flux = total_flux