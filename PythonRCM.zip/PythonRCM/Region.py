class Species:
    concentration: float = 0.0
    temperature: float = 0.0
    amount: float = 0.0
    z: int = 1

    def setZ(self, z):
        self.z = z
    def setConcentration(self, concentration: float):
        self.concentration = concentration

    def getConcentration(self) -> float:
        return self.concentration

    def setTemperature(self, temperature: float):
        self.temperature = temperature

    def setAmount(self, amount: float) -> None:
        self.amount = amount

    def getAmount(self) -> float:
        return self.amount

    def getZ(self):
        return self.z



class Region:

    def __init__(self):
        self.Na = Species()
        self.K = Species()
        self.A = Species()
        self.A.z = -1
        self.H = Species()
        self.Hb = Species()
        self.X = Species()
        self.Os = Species()
        self.Gluconate = Species()
        self.Glucamine = Species()
        self.Sucrose = Species()
        self.Caf = Species()
        self.Mgf = Species()
        self.Cat = Species()
        self.Mgt = Species()
        self.XHbm = Species()
        self.COs = Species()
        self.Hbpm = Species()
        self.pH = 0.0


    def getpH(self) -> float:
        # Get the pH value
        return self.pH

    def setpH(self, pH: float):
        # Set the pH value
        self.pH = pH

    def setTemperature(self, temperature: float):
        for species in vars(self).values():
            if isinstance(species, Species):
                species.setTemperature(temperature)

    def updateIonConcentration(self, ionName: str, concentration: float):
        # Update ion concentration in Region
        if hasattr(self, ionName):
            ion = getattr(self, ionName)
            if isinstance(ion, Species):
                ion.setConcentration(concentration)
            else:
                raise ValueError(f"{ionName} is not a valid Species.")
        else:
            raise ValueError(f"Ion name {ionName} not recognized.")
