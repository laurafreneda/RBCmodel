import random
from Region import Region
from Milestone import MileStone



class RBCModel:
    def __init__(self, cell, medium):
        self.cell = cell
        self.medium = medium
        self.sampling_time = 0
        self.delta_time = 0.1
        self.duration_experiment = 100
        self.total_cycle_count = 0
        self.results = []

    def setupDS(self):
        pass

    def runall(self):
        print('Starting Run All')

        local_milestones = [
            MileStone(time=10 / 60.0, name='PIEZO START'),  # time in minutes
            MileStone(time=20 / 60.0, name='PIEZO STOP'),
            MileStone(time=30 / 60.0, name='PIEZO END'),
            MileStone(time=self.duration_experiment / 60.0, name='END')
        ]

        print(f"Milestones: {[milestone.to_string() for milestone in local_milestones]}")

        while self.sampling_time * 60.0 <= self.duration_experiment:
            self.total_cycle_count += 1
            self.sampling_time += self.delta_time
            print(f"Sampling time: {self.sampling_time}")
            print(f"Total cycle count: {self.total_cycle_count}")

            mile_stone_found = False
            for milestone in local_milestones:
                if milestone.check(self.sampling_time):
                    if self.sampling_time + self.delta_time >= milestone.get_time():
                        new_delta_time = milestone.get_time() - self.sampling_time
                        if new_delta_time > 0:
                            self.delta_time = new_delta_time
                            mile_stone_found = True

                        self.sampling_time += self.delta_time
                        print(f"New sampling time: {self.sampling_time}")

                        if milestone.get_name() == 'END':
                            print(f"Ending simulation at time {self.sampling_time}")
                            self.process_results(self.results)
                            return
                        elif milestone.get_name() == 'PIEZO START':
                            self.start_piezo()
                        elif milestone.get_name() == 'PIEZO STOP':
                            self.stop_piezo()
                        elif milestone.get_name() == 'PIEZO END':
                            self.end_piezo()

            current_state = {
                'time': self.sampling_time * 60.0,
                'Em': random.uniform(-80, -60),
                'cell_Na': random.uniform(10, 20),
                'cell_K': random.uniform(100, 150),
                'cell_A': random.uniform(5, 15),
                'medium_Na': random.uniform(130, 150),
                'medium_K': random.uniform(4, 6),
                'medium_A': random.uniform(10, 20),
                'Vw': random.uniform(0.6, 0.8),
                'rA': random.uniform(0.9, 1.1),
                'rH': random.uniform(0.9, 1.1)
            }
            print(f"Appending result: {current_state}")  # Debugging line
            self.results.append(current_state)

    def process_results(self, results):
        if not results:
            print("No results to process.")
        else:
            print("Processing results...")
            for result in results:
                print(f"Time: {result['time']:.2f} s, Em: {result['Em']:.2f} mV, "
                      f"Cell Na: {result['cell_Na']:.2f} mM, Cell K: {result['cell_K']:.2f} mM, "
                      f"Cell A: {result['cell_A']:.2f} mM, Medium Na: {result['medium_Na']:.2f} mM, "
                      f"Medium K: {result['medium_K']:.2f} mM, Medium A: {result['medium_A']:.2f} mM, "
                      f"Vw: {result['Vw']:.2f}, rA: {result['rA']:.2f}, rH: {result['rH']:.2f}")

    def end_piezo(self):
        print("PIEZO ended")

    def stop_piezo(self):
        print("PIEZO stopped")

    def start_piezo(self):
        print("PIEZO started")


if __name__ == "__main__":
    cell = Region()
    medium = Region()
    rbc_model = RBCModel(cell, medium)
    rbc_model.runall()