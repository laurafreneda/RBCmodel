import pandas as pd
import numpy as np
import math
import logging
from run import RBCModel
from Napump import NaPump
from CaPumpMg2 import CaPumpMg2
from Region import Region


class PiezoLifespan:
    def __init__(self):
        self.results = None
        self.temperature = None
        self.rbc = None
        self.cell = Region()
        self.medium = Region()
        self.fraction = 1.0e-4
        self.default_fraction = 1.0e-4
        self.A_7 = 0.0
        self.cycle_per_print = 10
        self.time_field = 2880
        self.cycle_field = 1440
        self.naK = -3.2
        self.pmcak = 8e-6
        self.FMaxCa = 12.0
        self.tNaP = 4
        self.piezo_results = []

    def b_task(self):
        try:
            print("Initializing RBCModel...")  # Debug print
            self.rbc = RBCModel(self.medium, self.cell)
            self.rbc.setup()
            self.rbc.setupDS()
            self.rbc.runall()
            self.temperature = self.rbc.temperature
            time = self.rbc.get_sampling_time()
            max_time = float(self.time_field)
            cycles_per_output = int(self.cycle_field)
            cycle_counter = 0

            print("Setting initial publishing state...")  # Debug print
            self.rbc.set_publish(True)
            self.rbc.publish()
            self.rbc.set_publish(False)

            napump = NaPump(self.temperature, self.cell, self.medium)
            napump.compute_I()
            capump = CaPumpMg2(self.cell, self.medium, self.temperature)

            FMaxNa = napump.get_P_1()
            FMaxNaRev = napump.get_P_2()

            while time < max_time:
                time_in_minutes = time * 60.0
                self.rbc.setupDS()
                capump.set_default_fcapm(self.FMaxCa * math.exp(-self.pmcak * time_in_minutes))

                if time_in_minutes > self.tNaP:
                    napump.set_P_1(abs(FMaxNa * math.exp(-self.naK * (time_in_minutes - self.tNaP))))
                    napump.set_P_2(abs(FMaxNaRev * math.exp(-self.naK * (time_in_minutes - self.tNaP))))

                self.rbc.runall()

                time = self.rbc.get_sampling_time()
                cycle_counter += 1
                #print(cycles_per_output)

                if cycle_counter == cycles_per_output:
                    print(f"Cycle {cycle_counter}: Saving intermediate results...")  # Debug print

                    current_state = {
                        'time': time * 60.0,
                        'Em': self.rbc.Em,
                        'V/V': self.rbc.vv,
                        'cell_K': self.cell.K.getConcentration(),
                        'cell_A': self.cell.A.getConcentration(),
                        'medium_Na': self.medium.Na.getConcentration(),
                        'medium_K': self.medium.K.getConcentration(),
                        'medium_A': self.medium.A.getConcentration()
                    }
                    print(f"Appending result: {current_state}")  # Debugging line
                    self.results.append(current_state)
                    self.process_results(self.results)


        except Exception as e:
            logging.error(f"An error occurred: {e}")

    def process_results(self, results):
        if not results:
            print("No results to process.")
        else:
            print("Processing results...")
            for result in results:
                print(f"Time: {result['time']:.2f} s, Em: {result['Em']:.2f} mV, "
                      f"Cell V/V: {result['v/v']:.2f} mM, Cell K: {result['cell_K']:.2f} mM, "
                      f"Cell A: {result['cell_A']:.2f} mM, Medium Na: {result['medium_Na']:.2f} mM, "
                      f"Medium K: {result['medium_K']:.2f} mM, Medium A: {result['medium_A']:.2f} mM ")

        data_tuples = [
            (
                state.get('time', np.nan),
                state.get('Em', np.nan),
                state.get('vv', np.nan),
                state.get('cell_K', np.nan),
                state.get('cell_A', np.nan),
                state.get('medium_Na', np.nan),
                state.get('medium_K', np.nan),
                state.get('medium_A', np.nan)
            )
            for state in results
        ]

        results_array = np.array(data_tuples, dtype=[
            ('time', float), ('Em', float), ('vv', float), ('cell_K', float),
            ('cell_A', float), ('medium_Na', float), ('medium_K', float),
            ('medium_A', float)
        ])

        df = pd.DataFrame(results_array)
        df.to_csv('results.csv', index=False)
        print("Results processing completed.")
        return results_array
        # cycle_counter = 0

    # print("Finalizing and saving results...")  # Debug print
    #final_result = self.rbc.get_last_result()
    #self.piezo_results.append(final_result)
    #final_results.append(final_result)
    #time_results.append(time)

    # Save results to CSV files using pandas
    # pd.DataFrame({'Time': time_results}).to_csv('time_results.csv', index=False)
    # pd.DataFrame({'Piezo Results': self.piezo_results}).to_csv('piezo_results.csv', index=False)
    # pd.DataFrame({'Final Results': final_results}).to_csv('final_results.csv', index=False)

    # print("Results saved successfully.")  # Debug print
    # return time_results, self.piezo_results, final_results

    def get_inputs_as_array(self):
        return np.array([
            self.fraction,
            self.default_fraction,
            self.A_7,
            self.cycle_per_print,
            self.time_field,
            self.cycle_field,
            self.naK,
            self.pmcak,
            self.FMaxCa,
            self.tNaP
        ])


if __name__ == "__main__":
    p = PiezoLifespan()
    p.b_task()

    #time_results, piezo_results, final_results = p.background_task()

    # Get inputs as a numpy array
    #inputs_array = p.get_inputs_as_array()
    # print("Inputs as array:", inputs_array)  # Debug print

    # Save inputs to a CSV file using pandas
    #inputs_df = pd.DataFrame([inputs_array], columns=[
    #    'Fraction', 'Default Fraction', 'A_7', 'Cycles Per Print',
    #    'Time Field', 'Cycle Field', 'naK', 'pmcak', 'FMaxCa', 'tNaP'
    # ])
    # inputs_df.to_csv('inputs.csv', index=False)

#    print("Inputs saved to 'inputs.csv'.")  # Debug print
