import numpy as np
import pandas as pd
from typing import Dict, List
from run import RBCModel
from Region import Region


def make_rs_options() -> Dict[str, str]:
    return {}


def make_initial_ds() -> Dict[str, str]:
    return {}


def make_ds1_options() -> Dict[str, str]:
    return {}


def make_ds2_options() -> Dict[str, str]:
    return {}


def main():
    rs_options = make_rs_options()
    initial_ds = make_initial_ds()
    ds1_options = make_ds1_options()
    ds2_options = make_ds2_options()
    cell = Region()
    medium = Region()

    r = RBCModel(cell, medium)
    r.setup(rs_options, [])  # Initial setup
    r.setupDS(initial_ds, [])  # Initial setup for DS
    r.set_publish(True)
    r.publish()
    r.set_publish(False)
    r.run_all(None)  # Passing None as a placeholder for JTextArea

    cycles_per_output = 1
    cycle_count = 0

    while r.get_sampling_time() < 24.0:
        r.setup_ds(ds1_options, [])  # Setup DS1 options
        r.run_all(None)  # Passing None as a placeholder for JTextArea

        delta_na = 145.0 - r.get_medium_na_concentration()
        delta_k = 5.0 - r.get_medium_k_concentration()
        ds2_options["Add or remove NaCl"] = delta_na
        ds2_options["Add or remove KCl"] = delta_k

        r.setup_ds(ds2_options, [])  # Setup DS2 options

        time_in_minutes = r.get_sampling_time() * 60.0
        ca_pump = r.get_ca_pump()
        na_pump = r.get_na_pump()
        f_max_ca = ca_pump.get_default_fcapm()
        f_max_na = na_pump.get_p_1()
        f_max_na_rev = na_pump.get_p_2()
        pmca_k = 7.0e-6
        t_na_p = 0.0
        na_k = 7.0e-6

        ca_pump.set_default_fcapm(f_max_ca * np.exp(-pmca_k * time_in_minutes))
        if time_in_minutes > t_na_p:
            na_pump.set_p_1(f_max_na * np.exp(-na_k * (time_in_minutes - t_na_p)))
            na_pump.set_p_2(f_max_na_rev * np.exp(-na_k * (time_in_minutes - t_na_p)))

        r.run_all(None)  # Passing None as a placeholder for JTextArea
        cycle_count += 1

        if cycle_count == cycles_per_output:
            r.set_publish(True)
            r.publish()
            r.set_publish(False)
            cycle_count = 0

    r.write_csv("/Users/simon/TempStuff/Arieh/PiezoBig/cds_day_with_decay.csv")


if __name__ == "__main__":
    main()
