from Region import Region, Species

import math


class Goldman:

    def __init__(self, cell, medium):
        self.cell = Region()
        self.medium = Region()
        self.cell = cell
        self.medium = medium
        self.permeability_Na = 0.0015
        self.permeability_A = 1.2
        self.permeability_H = 2.0e-10
        self.permeability_K = 0.0017
        self.flux_Na = 0.0
        self.flux_A = 0.0
        self.flux_H = 0.0
        self.flux_K = 0.0
        self.Goldman_factor = 0.0
        self.P_11 = 0.0
        self.defaultPkm = 30.0
        self.pkm = 30.0
        self.pkcak = 0.01
        self.pgkh = 0.0
        self.rtoverf = 0.0  # Will be initialized later
        self.foverrt = 0.0  # Will be initialized later
        self.temperature = 37.0
        self.em = 0.0

    def gfactors(self, temperature: float, em):
        self.temperature = temperature
        self.em = em
        """Compute Goldman factors."""
        self.rtoverf = 0.086156 * (273.0 + self.temperature)
        self.foverrt = 1.0 / self.rtoverf
        self.Goldman_factor = self.em * self.foverrt

    def getRtoverf(self) -> float:
        return self.rtoverf

    def getFoverrt(self) -> float:
        return self.foverrt

    def compute_permeabilities(self, temperature: float, em):
        """Compute ion permeabilities."""
        self.gfactors(temperature, em)


        # Compute the Na permeability with a check for division by zero
        na_flux = self.gflux(self.cell.Na, self.medium.Na)
        if na_flux != 0:
            self.permeability_Na = abs(self.flux_Na / na_flux)
        else:
            self.permeability_Na = float('inf')  # Or handle it as appropriate


        # Compute the K permeability with a check for division by zero
        k_flux = self.gflux(self.cell.K, self.medium.K)
        if k_flux != 0:
            self.permeability_K = abs(self.flux_K / k_flux)
        else:
            self.permeability_K = float('inf')  # Or handle it as appropriate

    def computep_11(self):
        """Compute P_11."""
        i_62 = 1.0 / (1.0 + (self.cell.H.getConcentration() ** 4 / 2.5e-30))
        self.P_11 = self.pgkh * i_62

    def computep_6(self) -> float:
        """Compute P_6."""
        concentration = self.cell.Caf.getConcentration()
        return self.permeability_K + self.pkm * (concentration ** 4 / (self.pkcak ** 4 + concentration ** 4))

    def total_G_permeability_K(self):
        """Compute total Goldman permeability for K."""
        self.computep_11()
        return self.computep_6() + self.P_11

    def computeFKGardos(self, i_18: float):
        """Compute FK Gardos."""
        return self.gflux(self.cell.K, self.medium.K) * (self.computep_6() - self.permeability_K) / i_18

    def compute_flux(self, temperature, i_18, em):
        self.em = em

        """Compute fluxes for different ions."""
        self.gfactors(temperature, self.em)
        self.flux_Na = self.fullgflux(self.cell.Na, self.medium.Na, self.permeability_Na, i_18)
        self.flux_A = self.fullgflux(self.cell.A, self.medium.A, self.permeability_A, i_18)
        self.flux_H = self.fullgflux(self.cell.H, self.medium.H, self.permeability_H, i_18)
        self.flux_K = self.fullgflux(self.cell.K, self.medium.K, self.total_G_permeability_K(), i_18)

    def gflux(self, cell_species, medium_species):
        goldman_factor = self.getGoldmanFactor()
        #print(f"goldman_factor = {goldman_factor}")

        if abs(goldman_factor) < 1e-10:  # Choose an appropriate small threshold
            # Use L'Hôpital's rule for small goldman_factor
            return -cell_species.getZ() * (medium_species.getConcentration() - cell_species.getConcentration())

        numerator = medium_species.getConcentration() - cell_species.getConcentration() * math.exp(
            cell_species.getZ() * goldman_factor)
        denominator = 1.0 - math.exp(cell_species.getZ() * goldman_factor)

        return -cell_species.getZ() * goldman_factor * numerator / denominator

    def fullgflux(self, cell, medium, permeability: float, i_18: float):
        """Compute full Goldman flux."""
        return (permeability / i_18) * self.gflux(cell, medium)

    # Getters and Setters
    def getGoldmanFactor(self):
        return self.Goldman_factor

    def getPkm(self) -> float:
        return self.pkm

    def getDefaultPkm(self):
        return self.defaultPkm

    def setDefaultPkm(self, pkm: float):
        self.defaultPkm = pkm
        self.setPkm(pkm)

    def setPkm(self, pkm: float):
        self.pkm = pkm

    def getPkcak(self):
        return self.pkcak

    def setPkcak(self, pkcak: float):
        self.pkcak = pkcak

    def getFlux_A(self):
        return self.flux_A

    def setFlux_A(self, flux_A: float):
        self.flux_A = flux_A

    def getFlux_Na(self):
        return self.flux_Na

    def setFlux_Na(self, flux_Na: float):
        self.flux_Na = flux_Na

    def getFlux_K(self):
        return self.flux_K

    def setFlux_K(self, flux_K: float):
        self.flux_K = flux_K

    def getFlux_H(self) -> float:
        return self.flux_H

    def setFlux_H(self, flux_H: float):
        self.flux_H = flux_H

    def getPermeability_K(self):
        return self.permeability_K

    def setPermeability_K(self, permeability_K: float):
        self.permeability_K = permeability_K

    def getPgkh(self) -> float:
        return self.pgkh

    def setPgkh(self, pgkh: float):
        self.pgkh = pgkh

    def getPermeability_Na(self):
        return self.permeability_Na

    def setPermeability_Na(self, permeability_Na: float):
        self.permeability_Na = permeability_Na

    def getPermeability_A(self) -> float:
        return self.permeability_A

    def setPermeability_A(self, permeability_A: float):
        self.permeability_A = permeability_A

    def getPermeability_H(self):
        return self.permeability_H

    def setPermeability_H(self, permeability_H: float):
        self.permeability_H = permeability_H
