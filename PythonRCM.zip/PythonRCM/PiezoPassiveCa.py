from dataclasses import dataclass, field
import numpy as np
from Goldman import Goldman
from PiezoGoldman import PiezoGoldman
from Region import Region


class PiezoPassiveCa:
    def __init__(self, cell, medium):
        self.cell = cell  # Assume 'Region' is the type of cell
        self.medium = medium  # Assume 'Region' is the type of medium
        self.cell = Region()
        self.medium = Region()
        piezoGoldman = PiezoGoldman(cell=self.cell, medium=self.medium)  # Assume 'PiezoGoldman' is the type
        self.set_flux(0.0)
        self.set_fcalm(0.0)
        self.PgoldmanFactor = piezoGoldman.get_Goldman_factor()  # Initialize PgoldmanFactor
        self.i_18 = None

    def compute_flux(self, I_18):
        self.i_18 = I_18
        # Compute the flux based on the given parameter I_18
        Caf_medium = self.medium.Caf.getConcentration()
        Caf_cell = self.cell.Caf.getConcentration()

        if abs(self.PgoldmanFactor) < 1e-10 or abs(self.get_fcalm()) < 1e-10:
            self.flux = 0.0
        else:
            exp_term = np.exp(2.0 * self.PgoldmanFactor)
            self.flux = -(self.get_fcalm() / self.i_18) * 2.0 * self.PgoldmanFactor * (
                    Caf_medium - Caf_cell * exp_term) / (1.0 - exp_term)

        self.set_flux(self.flux)
        return self.flux

    def get_fcalm(self) -> float:
        # Getter for fcalm property
        return self.fcalm

    def set_fcalm(self, fcalm: float):
        # Setter for fcalm property
        self.fcalm = fcalm

    def get_flux(self) -> float:
        # Getter for flux property
        return self.flux

    def set_flux(self, flux: float):
        # Setter for flux property
        self.flux = flux
