import csv
import logging
import math
import os
from typing import Dict
import numpy as np
import pandas as pd
from A23187 import A23187
from CaPumpMg2 import CaPumpMg2
from CarrierMediated import CarrierMediated
from Cotranssport import Cotransport
from Eqsolver import EqSolver, Eqca, Eqmg, ComputeAllFluxes, Ligs_eqs
from Goldman import Goldman
from js import JacobsStewart
from Milestone import MileStone
from Napump import NaPump
from PassiveCa import PassiveCa
from Piezo import Piezo
from PiezoGoldman import PiezoGoldman
from PiezoPassiveCa import PiezoPassiveCa
from Region import Region
from WaterFlux import WaterFlux


class RBCModel:
    def __init__(self, cell: Region, medium: Region):
        # Initialize basic attributes
        self.p = None
        self.set_integration_interval_factor = None
        self.i_43 = None
        self.p_stop = None
        self.p_end = None
        self.p_start = None
        self.is_cancelled = None
        self.cell = cell
        self.medium = medium

        # Define default properties
        self.vlysis = None
        self.delta_Ca = None
        self.i_40 = None
        self.i_72 = None
        self.mgbal = 0.0159
        self.net_charge_hb = None
        self.nXdefOxy = None
        self.fraction = None
        self.BufferType = None
        self.hb_content_str = None
        self.set_vw(0.0)
        self.initialK = 195
        self.initialNa = 10
        self.na_efflux_rev = 0.0
        self.na_efflux_fwd = 0.0
        self.local_milestones = []
        self.endTime = None
        self.cycles_per_print = None
        self.i_67 = None
        self.finished = None
        self.i_74 = None
        self.set_i_79(0.75)
        self.i_73 = None
        self.lig_eq = None
        self.X_3 = 0.0
        self.lig_eq1 = 0.0
        self.lig_eq2 = 0.0
        self.lig_eq3 = 0.0
        self.hb_content = None
        self.pH = None
        self.verbose = False
        self.lifespan = True
        self.cycle_count = 0
        self.stage = 0
        self.n_its = 0
        self.results = []
        self.sampling_time = 0.0
        self.duration_experiment = 0.0
        self.temperature = 37.0
        self.Q10Passive = 2.0
        self.i_18 = 0.0
        self.Em = 0.0
        self.dp = 4
        self.total_flux = 0.0
        self.total_flux_A = 0.0
        self.total_flux_Ca = 0.0
        self.total_flux_H = 0.0
        self.total_flux_K = 0.0
        self.total_flux_Na = 0.0
        self.delta_time = None
        self.fHb = 0.0
        self.A_1 = -10.0
        self.A_10 = 0.0
        self.A_11 = 0.0
        self.A_12 = 0.0
        self.A_2 = 0.0645
        self.A_3 = 0.0258
        self.A_5 = 2.813822508658947e-8
        self.A_7 = 0.0
        self.A_8 = 0.0
        self.atp = 1.2
        self.netChargeHb = 0.0
        self.i_73 = 0.0
        self.pit0 = 7.2
        self.nHb = 0.0
        self.vv = 0.0
        self.mchc = 0.0
        self.set_hb_content(34.0)
        self.density = 0.0
        self.buffer_conc = 10.0
        self.delta_H = 0.0
        self.dedgh = 0.0
        self.diff2 = 1.0E-5
        self.diff3 = 1.0E-5
        self.ff = 0.0
        self.edghk1 = 0.0
        self.edghk2 = 0.0
        self.edgcak = 0.0
        self.edgmgk = 0.0
        self.A_5 = 0.0
        self.it_counter = 0
        self.lig_hb = 0.0
        self.edg4 = 0.0
        self.edg3 = 0.0
        self.edg2 = 0.0
        self.edgca = 0.0
        self.edgmg = 0.0
        self.edgneg = 0.0
        self.edghnew = 0.0
        self.edghold = 0.0
        self.edgto = 0.0
        self.mgb0 = 0.0
        self.benz2k = 5.0E-5
        self.benz2 = 0.0
        self.cbenz2 = 0.0
        self.b1ca = 0.0
        self.b1cak = 0.0
        self.rA = 0.0
        self.rH = 0.0
        self.set_vlysis(1.45)
        self.T_6 = 0.0
        self.total_cycle_count = 0.0
        self.pkhepes = 0.0
        self.fG = 0.1
        self.Na_to_K = 1.5
        self.result_list = []
        self.do_publish = True
        self.mileStonePos = 0
        self.mileStoneOperation = None
        self.mile_stones = []
        self.integration_interval_factor = 0.01
        self.oldJSPermeability = 0.00
        self.defaultFraction = 0.0
        self.finalPiezoFK = 0.0
        self.finalPiezoFNa = 0.0
        self.finalPiezoFA = 0.0
        self.finalPiezoFCa = 0.0
        self.finalPiezoHct = 0.0
        self.finalPiezoCCa = 0.0
        self.finalPiezoResult = {}
        self.final_piezo_result = None
        self.final_piezo_hct = None
        self.final_piezo_cc = None
        self.compute_delta_time = True
        self.piezo_started = False
        self.piezo_stopped = False
        self.piezo_ended = False

        # Initialize Regions with default concentrations
        self.medium.Gluconate.setConcentration(0.0)
        self.medium.Glucamine.setConcentration(0.0)
        self.cell.Gluconate.setConcentration(0.0)
        self.medium.Glucamine.setConcentration(0.0)
        self.cell.Mgt.setAmount(2.5)
        self.dpgp = 0.0
        self.set_initial_cell_concentrations()
        self.set_initial_medium_concentrations()
        self.set_alpha(0.0)

        # Initialize other deltas
        self.fixed_delta_time = 0.001
        self.delta_A = 0.0
        self.delta_H = 0.0
        self.delta_M = 0.0
        self.delta_N = 0.0
        self.delta_K = 0.0
        self.delta_Mg = 0.0
        self.delta_Na = 0.0
        self.delta_Water = 0.0

        # Initialize model components
        self.piezo = Piezo()
        self.pgold = PiezoGoldman(cell=self.cell, medium=self.medium)
        self.cpu = CaPumpMg2(cell=self.cell, medium=self.medium, temp=self.temperature)
        self.p_pass_ca = PiezoPassiveCa(cell=self.cell, medium=self.medium)
        self.jstu = JacobsStewart(self.cell, self.medium)
        self.npu = NaPump(temperature=self.temperature, cell=self.cell, medium=self.medium)
        self.cme = CarrierMediated(
            cell=self.cell, medium=self.medium,
            Naconcell=self.cell.Na.getConcentration(),
            Kconcell=self.cell.K.getConcentration(),
            Aconcell=self.cell.A.getConcentration(),
            Naconmed=self.medium.Na.getConcentration(),
            Kconmed=self.medium.K.getConcentration(),
            Aconmed=self.medium.A.getConcentration(),
            i_18=self.i_18
        )
        self.cot = Cotransport(cell=self.cell, medium=self.medium)
        self.gold = Goldman(self.cell, self.medium)
        self.pass_ca = PassiveCa(self.cell, self.medium)
        self.wtflux = WaterFlux(cell=self.cell, medium=self.medium)
        self.js = JacobsStewart(cell=self.cell, medium=self.medium)
        self.a23 = A23187(cell=self.cell, medium=self.medium, i_18=self.i_18)
        self.ms = MileStone()
        self.results_df = pd.DataFrame()
        self.total_cycle_count = 0
        self.results = []
        self.data = {
            "Vw_old": [],
            "Vw": [],
            "Hb_Concentration": [],
            "fHb": [],
            "Na_Amount": [],
            "K_Amount": [],
            "A_Amount": [],
            "NetChargeHb": [],
            "pHi": [],
            "Density": [],
            "Fraction": [],
            "Medium_Na_Concentration": [],
            "Medium_K_Concentration": [],
            "Medium_A_Concentration": [],
            "Medium_Gluconate_Concentration": [],
            "Medium_Glucamine_Concentration": [],
            "Medium_Sucrose_Concentration": [],
            "Buffer_Conc": [],
            "Medium_Hb_Concentration": [],
            "Medium_Mgt_Concentration": [],
            "Medium_Cat_Concentration": [],
            "Edgto": [],
            "pHo": [],
            "Na_Concentration_Cell": [],
            "K_Concentration_Cell": [],
            "A_Concentration_Cell": [],
            "Mgf_Concentration": [],
            "time": []
        }

    def set_lifespan(self, state: bool):
        self.lifespan = state

    # def get_publish_order(self) -> List[str]:
    #    """Return the current publish order."""
    #   return self._publish_order

    #def set_publish_order(self, order):
    #   """Set the publish order."""
    #  self._publish_order = order

    def set_verbose(self, verbose: bool) -> None:
        """Set the verbose flag."""
        self.verbose = verbose

    def set_initial_medium_concentrations(self):
        self.medium.Na.setConcentration(145.0)
        self.medium.K.setConcentration(5.0)
        self.medium.A.setConcentration(145.0)
        self.medium.H.setConcentration(0.0)
        self.buffer_conc = 10.0
        self.medium.Hb.setConcentration(0.0)

    def set_initial_cell_concentrations(self):
        self.cell.Na.setConcentration(10.0)
        self.cell.K.setConcentration(140.0)
        self.cell.A.setConcentration(95.0)
        self.cell.H.setConcentration(0.0)
        self.cell.Hb.setConcentration(0.0)
        self.cell.X.setConcentration(0.0)
        self.cell.Mgt.setConcentration(0.0)
        self.cell.XHbm.setConcentration(0.0)

    def set_mg_defaults(self) -> None:
        print("Starting mg_defaults")

        self.cell.Mgt.setAmount(2.5)
        self.medium.Mgt.setConcentration(0.2)

        self.atp = 1.2
        self.set_dpgp(15.0)
        self.vv = 1.0 - self.A_11 + self.get_vw()

        # Update EqSolver instance with RBC_model properties
        #eq_solver.VV = self.vv
        #eq_solver.atp = self.atp
        #eq_solver.dpgp = self.dpgp
        #eq_solver.vw = self.get_vw()
        #eq_solver.hb_content = self.hb_content
        #eq_solver.cell = self.cell

        # Create an instance of EqSolver
        eq_solver = EqSolver(self.atp, self.dpgp, self.vv, self.get_vw(), self.get_mgb0, self.cell, self.medium,
                             self.buffer_conc, self.A_5, self.A_8, self.lig_hb, self.delta_H, self.dedgh)

        # Create an instance of Eqmg
        eqmg_instance = Eqmg(self.buffer_conc, self.delta_H, self.lig_hb, self.A_8, self.dedgh, self.atp,
                             self.get_mgb0(),
                             self.get_vw(), self.vv, self.cell.Mgt.getAmount(),
                             self.get_dpgp(), self.cell.Mgf.getConcentration())

        # Run the Newton-Raphson method
        conc = eq_solver.newton_raphson(eqmg_instance, initial=0.02, step=1.0E-4, stop=1.0E-5, max_its=100,
                                        initial_its=0, verbose=False)

        # Set the calculated concentration
        self.cell.Mgf.setConcentration(conc)

    def mgbufferscreenRS(self):
        print('Starting Mg buffer')

        # Create an instance of EqSolver
        eq_solver = EqSolver(self.atp, self.dpgp, self.vv, self.get_vw(), self.get_mgb0, self.cell, self.medium,
                             self.buffer_conc, self.A_5, self.A_8, self.lig_hb, self.delta_H, self.dedgh)

        self.medium.Mgt.setConcentration(0.2)
        self.cell.Mgt.setAmount(self.cell.Mgt.getConcentration())
        self.set_mgb0(0.05)
        self.set_dpgp(15.0)

        eqmg_instance = Eqmg(self.buffer_conc, self.delta_H, self.lig_hb, self.A_8, self.dedgh, self.atp,
                             self.get_mgb0(),
                             self.get_vw(), self.vv, self.cell.Mgt.getAmount(),
                             self.get_dpgp(), self.cell.Mgf.getConcentration())

        # Run the Newton-Raphson method
        conc = eq_solver.newton_raphson(eqmg_instance, initial=0.02, step=1.0E-4, stop=1.0E-5, max_its=100,
                                        initial_its=0, verbose=False)

        # Set the calculated concentration
        self.cell.Mgf.setConcentration(conc)

    def setcadefaults(self):
        print("Starting ca defaults")

        self.cell.Cat.setAmount(5.8E-4)
        if self.get_vw() == 0:
            concentration = 0
        else:
            concentration = self.cell.Cat.getAmount() / self.get_vw()

        self.cell.Cat.setConcentration(concentration)

        self.medium.Cat.setConcentration(1.0)

        self.set_alpha(0.3)

        self.setB1ca(0.026)

        self.setB1cak(0.014)

        self.set_benz2(0.0)

        self.benz2k = 5.0E-5

        self.cell.Caf.setConcentration(1.12E-4)

        mgf_concentration = self.medium.Mgt.getConcentration()

        self.medium.Mgf.setConcentration(mgf_concentration)

        caf_concentration = self.medium.Cat.getConcentration()

        self.medium.Caf.setConcentration(caf_concentration)

    def cabufferscreenRS(self, options):
        print('Starting Ca buffer')

        # Handle the concentration of Cat in the medium
        temp = options.get("cato-medium")
        if temp is not None:
            self.medium.Cat.setConcentration(float(temp))
            options["cato-medium"] = float(temp)
        else:
            self.medium.Cat.setConcentration(1.0)
            options["cato-medium"] = 1.0

        # Handle the Ca buffer concentration
        temp = options.get("add-ca-buffer")
        if temp is not None:
            self.set_b1ca(float(temp))
            options["add-ca-buffer"] = float(temp)
        else:
            self.set_b1ca(0.026)
            options["add-ca-buffer"] = 0.026

        # Handle the dissociation constant of the Ca buffer
        temp = options.get("kd-of-ca-buffer")
        if temp is not None:
            self.set_b1cak(float(temp))
            options["kd-of-ca-buffer"] = float(temp)
        else:
            self.set_b1cak(0.014)
            options["kd-of-ca-buffer"] = 0.014

        # Handle the alpha value
        temp = options.get("alpha")
        if temp is not None:
            self.set_alpha(float(temp))
            options["alpha"] = float(temp)
        else:
            self.set_alpha(0.3)
            options["alpha"] = 0.3

        # Handle the benz2loaded parameter
        temp = options.get("benz2loaded")
        if temp is not None:
            self.set_benz2(float(temp))
            options["benz2loaded"] = float(temp)
        else:
            self.set_benz2(0.0)
            options["benz2loaded"] = 0.0

        # Set the concentration of Cbenz2 based on benz2
        if self.get_benz2() != 0 and self.get_vw() != 0:
            self.set_cbenz2(self.get_benz2() / self.get_vw())
            options["cbenz2"] = self.get_cbenz2()
        else:
            self.set_cbenz2(0.0)
            options["cbenz2"] = self.get_cbenz2()

        # Handle the PMCA FCaPmax value
        temp = options.get("PMCA FCaPmax")
        if temp is not None:
            self.cpu.set_default_fcapm(float(temp))
            options["PMCA FCaPmax"] = float(temp)

        # Set a default value for capk
        self.cpu.set_capk(2.0E-4)
        options["capk"] = 2.0E-4

        # Handle the hill coefficient
        temp = options.get("hills")
        if temp is not None:
            self.cpu.set_h1(float(temp))
            options["hills"] = float(temp)
        else:
            self.cpu.set_h1(4.0)
            options["hills"] = 4.0

        # Handle the electrochemical stoichiometry
        temp = options.get("pump-electro")
        if temp is not None:
            capstoich = int(temp)
            self.cpu.set_cah(2 - capstoich)
            options["pump-electro"] = 2 - capstoich

        # Handle the inhibition constant for H+ ions
        temp = options.get("h+ki")
        if temp is not None:
            self.cpu.set_hik(float(temp))
            options["h+ki"] = float(temp)
        else:
            self.cpu.set_hik(4.0E-7)
            options["h+ki"] = 4.0E-7

        # Handle the K1/2 value for Mg2+
        temp = options.get("Mg2+K1/2")
        if temp is not None:
            self.cpu.set_capmgk(float(temp))
            options["Mg2+K1/2"] = float(temp)
        else:
            self.cpu.set_capmgk(0.1)
            options["Mg2+K1/2"] = 0.1

        # Handle the PCaG value
        temp = options.get("PCaG")
        if temp is not None:
            self.pass_ca.set_fcalm(float(temp))
            options["PCaG"] = float(temp)

        # Handle the PKGardosMax value
        temp = options.get("PKGardosMax")
        if temp is not None:
            self.gold.setDefaultPkm(float(temp))
            options["PKGardosMax"] = float(temp)

        # Handle the KCa Gardos channel value
        temp = options.get("KCa Gardos channel")
        if temp is not None:
            self.gold.setPkcak(float(temp))
            options["KCa Gardos channel"] = float(temp)

        # If benz2 is non-zero, set Caf concentration
        if self.get_benz2() != 0.0:
            self.cell.Caf.setConcentration(1.0E-8)
            options["Caf-concentration"] = 1.0E-8
            self.canr()

    def na_pump_screen_rs(self, options):

        self.npu.set_flux_fwd(float(self.na_efflux_fwd))
        options["Na/K pump Na efflux"] = self.npu.get_flux_fwd()

        self.npu.set_flux_rev(float(self.na_efflux_rev))
        options["na-efflux-rev"] = self.npu.get_flux_rev()

        self.cell.Na.setConcentration(self.initialNa)
        self.cell.Na.setAmount(self.initialNa * self.get_vw())
        options["CNa"] = self.cell.Na.getConcentration()

        self.cell.K.setConcentration(self.initialK)
        self.cell.K.setAmount(self.initialK * self.get_vw())
        options["CK"] = self.cell.K.getConcentration()

        self.Q10Passive = 4
        #used_options.append("Q10 passive")

    def cellwater_screen_rs(self, options):

        print('Starting Cell Water...')

        self.cell.Hb.setAmount(self.get_hb_content() * 10.0 / 64.5)
        self.set_i_79(1.0 - (self.get_hb_content() / 136.0))
        print(f'cell water{self.get_i_79(),self.get_hb_content()}')

        self.set_vlysis(1.45)
        #self.set_i_79(self.get_vw())
        options["Vw"] = self.get_vw()
        options["lytic-cell-water"] = self.get_vlysis()

        #print(self.get_vlysis(), self.get_vw(), self.get_i_79())

    def cellanionproton_screen_rs(self, options):
        temp = self.cell.A.getConcentration()
        self.cell.A.setConcentration(float(temp))
        options["CA"] = self.cell.A.getConcentration()

    def chargeandpi_screen_rs(self, options):

        self.set_A_1(-1.0)
        self.set_pit0(7.2)
        options["a"] = self.get_A_1()
        options["pit0"] = self.get_pit0()

        #  elif temp == "S": (sickle)
        #     model.set_a_1(-8.0)
        #    model.set_pit0(7.4)
        # used_options.append("Hb A or S")

    def computeRS(self):
        # Update concentrations in the medium
        A_concentration = self.medium.A.getConcentration()
        #print(self.medium.A.getConcentration())
        Mgt_concentration = self.medium.Mgt.getConcentration()
        Cat_concentration = self.medium.Cat.getConcentration()
        self.medium.A.setConcentration(A_concentration + 2.0 * (Mgt_concentration + Cat_concentration))

        # Compute other variables and properties
        self.computehtRS()

        self.A_7 = self.fraction
        self.A_8 = self.A_7 / (1.0 - self.A_7)

        self.mediumconcentrationsRS()
        self.cellphetc()
        self.nakamountsmgcaconcRS()
        self.secureisonoticityRS()
        #cell_A_amount = self.cell.A.getAmount()
        #benz2 = self.get_benz2()
        #cell_Na_amount = self.cell.Na.getAmount()
        #cell_K_amount = self.cell.K.getAmount()
        #cell_Mgt_amount = self.cell.Mgt.getAmount()
        #cell_Cat_amount = self.cell.Cat.getAmount()
        cell_Hb_amount = self.cell.Hb.getAmount()
        #cell_X_amount = self.cell.X.getAmount()

        if self.cell.X.getAmount() == 0:
            self.A_10 = 0

        else:
            self.A_10 = (
                    (self.cell.A.getAmount() +
                     2.0 * self.get_benz2() -
                     self.cell.Na.getAmount() +
                     self.cell.K.getAmount() +
                     2.0 * self.cell.Mgt.getAmount() +
                     2.0 * self.cell.Cat.getAmount() +
                     self.nHb * self.cell.Hb.getAmount())
                    / self.cell.X.getAmount()
            )

        self.nXdefOxy = self.A_10
        self.netChargeHb = self.nHb * cell_Hb_amount
        self.fluxesRS()
        self.cycle_count = 0
        self.n_its = 0
        self.duration_experiment = 0.0
        self.stage = 0

    def computehtRS(self):
        print("Starting computeTRS")
        self.vv = 1.0 - self.A_11 + self.get_vw()
        self.mchc = self.get_hb_content() / self.vv
        self.density = (self.get_hb_content() / 100.0 + self.get_vw()) / self.vv

    def mediumconcentrationsRS(self):
        print("Starting medium concentrations")
        self.medium.H.setConcentration(10 ** -self.medium.getpH())
        self.pkhepes = 7.83 - 0.014 * self.temperature
        self.A_5 = 10 ** (-self.pkhepes)
        self.medium.Hb.setConcentration(
            self.buffer_conc * self.medium.H.getConcentration() / (self.A_5 + self.medium.H.getConcentration()))

        if self.medium.getpH() >= self.A_12:
            self.medium.Na.setConcentration(
                self.medium.A.getConcentration() + self.edgneg + self.medium.Gluconate.getConcentration() + self.buffer_conc -
                self.medium.Hb.getConcentration() - self.medium.Glucamine.getConcentration() -
                self.medium.K.getConcentration() - 2.0 * self.medium.Mgf.getConcentration() - 2.0 * self.medium.Caf.getConcentration()
            )
        else:
            self.medium.K.setConcentration(
                self.medium.A.getConcentration() + self.edgneg + self.medium.Gluconate.getConcentration() + self.buffer_conc -
                self.medium.Hb.getConcentration() - self.medium.Glucamine.getConcentration() -
                self.medium.Na.getConcentration() - 2.0 * self.medium.Mgf.getConcentration() - 2.0 * self.medium.Caf.getConcentration()
            )

    def cellphetc(self):
        print("Starting cellphetc")
        if self.medium.A.getConcentration() == 0 or self.cell.A.getConcentration() == 0:
            self.rA = 0.0000000000001
        else:
            self.rA = self.medium.A.getConcentration() / self.cell.A.getConcentration()
        self.rH = self.rA

        self.cell.H.setConcentration(self.rH * self.medium.H.getConcentration())
        if self.medium.H.getConcentration() <= 0:
            # Handle the case where concentration is zero or negative
            print("Warning: Hydrogen ion concentration is zero or negative. Setting pH to a high value.")
            self.cell.setpH(14.0)  # Assuming the maximum pH value for a basic solution
        else:
            # Calculate pH using -log10[H]
            pH = -math.log10(self.medium.H.getConcentration())
            self.cell.setpH(pH)
        if self.rA <= 0:
            # Handle invalid rA values
            print("Warning: rA value is zero or negative. Setting Em to a default value.")
            self.Em = 0.0  # or a default value like 0, depending on your application
        else:
            # Compute Em using the given formula
            self.Em = -0.086156 * (273.0 + self.temperature) * math.log(self.rA)

        if self.get_vw() == 0 or self.A_2 * self.cell.Hb.getAmount() == 0 or self.A_3 * self.get_hb_content() == 0:
            self.fHb = 1.0
        else:
            self.fHb = 1.0 + self.A_2 * self.cell.Hb.getAmount() / self.get_vw() + self.A_3 * (
                    self.cell.Hb.getAmount() / self.get_vw()) ** 2

        #Double.valueOf(1.0D + this.A_2.doubleValue() * this.cell.Hb.getAmount().doubleValue() / getVw().doubleValue() + this.A_3.doubleValue() * Math.pow(this.cell.Hb.getAmount().doubleValue() / getVw().doubleValue(), 2.0D));

        self.i_74 = self.pit0 - 0.592
        self.nHb = self.A_1 * (self.cell.getpH() - self.i_74)
        print(f"This is Em inside cellphetc: {self.Em}")
        print(f"This is fHb inside cellphetc: {self.fHb}")
        print(f"This is nHb inside cellphetc: {self.nHb}")

    def nakamountsmgcaconcRS(self):
        print("Starting naka")
        self.cell.Na.setAmount(self.cell.Na.getConcentration() * self.get_vw())
        self.cell.K.setAmount(self.cell.K.getConcentration() * self.get_vw())
        self.cell.A.setAmount(self.cell.A.getConcentration() * self.get_vw())

        if self.get_vw() == 0:
            self.cell.Mgt.setConcentration(0.0)
            self.cell.Cat.setConcentration(0.0)
        else:
            self.cell.Mgt.setConcentration(self.cell.Mgt.getAmount() / self.get_vw())
            self.cell.Cat.setConcentration(self.cell.Cat.getAmount() / self.get_vw())

    def secureisonoticityRS(self):
        print("Starting secure")
        # Calculate the sum of various concentrations
        summ = (self.medium.Na.getConcentration() +
                self.medium.K.getConcentration() +
                self.medium.A.getConcentration() +
                self.buffer_conc +
                self.medium.Gluconate.getConcentration() +
                self.medium.Glucamine.getConcentration() +
                self.medium.Sucrose.getConcentration() +
                self.medium.Mgt.getConcentration() +
                self.medium.Cat.getConcentration())

        # Calculate the sum of various amounts
        sumq = (self.cell.Na.getAmount() +
                self.cell.K.getAmount() +
                self.cell.A.getAmount() +
                (self.cell.Mgf.getConcentration() + self.cell.Caf.getConcentration()) * self.get_vw() +
                self.fHb * self.cell.Hb.getAmount() +
                self.get_benz2())

        # Set the amount for cell.X
        self.cell.X.setAmount(self.get_vw() * summ - sumq)

    def set_temp_permeability_options(self, options):
        default_temp = self.temperature

        piold = self.get_pit0() - 0.016 * default_temp
        pinew = self.get_pit0() - 0.016 * self.temperature
        self.i_74 = pinew
        new_phc = pinew - piold + self.cell.getpH()
        self.cell.setpH(new_phc)
        self.cell.H.setConcentration(10.0 ** -self.cell.getpH())

        self.pkhepes = 7.83 - 0.014 * self.temperature
        a5old = self.A_5
        m4old = self.medium.H.getConcentration()
        self.A_5 = 10.0 ** -self.pkhepes
        self.medium.H.setConcentration(self.A_5 * m4old / a5old)
        self.medium.setpH(-math.log(self.medium.H.getConcentration()) / math.log(10.0))
        self.medium.Hb.setConcentration(
            self.buffer_conc * self.medium.H.getConcentration() / (self.A_5 + self.medium.H.getConcentration()))

        temp = options.get("Pw")
        if temp is not None:
            self.wtflux.setPermeability(float(temp))
            options["Pw"] = self.wtflux.getPermeability()

        temp = options.get("PK")
        if temp is not None:
            self.gold.setPermeability_K(float(temp))
            options["PK"] = self.gold.getPermeability_K()

        # Retrieve and set 'pgkh'
        temp = options.get("pgkh")
        if temp is not None:
            self.gold.setPgkh(float(temp))
            options["pgkh"] = self.gold.getPgkh()  # Update the dictionary after setting the value

        # Retrieve and set 'PNa'
        temp = options.get("PNa")
        if temp is not None:
            self.gold.setPermeability_Na(float(temp))
            options["PNa"] = self.gold.getPermeability_Na()  # Update the dictionary after setting the value

        # Retrieve and set 'PA'
        temp = options.get("PA")
        if temp is not None:
            self.gold.setPermeability_A(float(temp))
            options["PA"] = self.gold.getPermeability_A()  # Update the dictionary after setting the value

        # Retrieve and set 'PH'
        temp = options.get("PH")
        if temp is not None:
            self.gold.setPermeability_H(float(temp))
            options["PH"] = self.gold.getPermeability_H()  # Update the dictionary after setting the value

        # Retrieve and set 'PCa'
        temp = options.get("PCa")
        if temp is not None:
            self.pass_ca.set_fcalm(float(temp))
            options["PCa"] = self.pass_ca.get_fcalm()  # Update the dictionary after setting the value

        # Retrieve and set 'PA23CaMg'
        temp = options.get("PA23CaMg")
        if temp is not None:
            self.a23.set_permeability_Mg(float(temp))
            options["PA23CaMg"] = self.a23.get_permeability_Mg()  # Update the dictionary after setting the value

        # Retrieve and set 'a23cam'
        temp = options.get("a23cam")
        if temp is not None:
            self.a23.set_camk(float(temp))
            options["a23cam"] = self.a23.get_camk()  # Update the dictionary after setting the value
        else:
            self.a23.set_camk(10.0)
            options["a23cam"] = self.a23.get_camk()  # Set default value in the dictionary

        # Retrieve and set 'a23cai'
        temp = options.get("a23cai")
        if temp is not None:
            self.a23.set_caik(float(temp))
            options["a23cai"] = self.a23.get_caik()  # Update the dictionary after setting the value
        else:
            self.a23.set_caik(10.0)
            options["a23cai"] = self.a23.get_caik()  # Set default value in the dictionary

        # Retrieve and set 'a23mgi'
        temp = options.get("a23mgi")
        if temp is not None:
            self.a23.set_mgik(float(temp))
            options["a23mgi"] = self.a23.get_mgik()  # Update the dictionary after setting the value
        else:
            self.a23.set_mgik(10.0)
            options["a23mgi"] = self.a23.get_mgik()  # Set default value in the dictionary

        self.a23.set_permeability_Ca(self.a23.get_permeability_Mg())

        eq_solver = EqSolver(self.atp, self.dpgp, self.vv, self.get_vw(), self.get_mgb0(), self.cell, self.medium,
                             self.buffer_conc, self.A_5, self.A_8, self.lig_hb, self.delta_H, self.dedgh)

        eqmg_instance = Eqmg(buffer_conc=self.buffer_conc, delta_H=self.delta_H,
                             lig_hb=self.lig_hb, A_8=self.A_8, dedgh=self.dedgh, atp=self.atp,
                             mgb0=self.get_mgb0(), vw=self.get_vw(), vv=self.vv, Mgt_Amount=self.cell.Mgt.getAmount(),
                             dpgp=self.get_dpgp(), local_mgf=self.cell.Mgf.getConcentration())

        temp = options.get("Hb Deoxy or Re-Oxy")
        if temp is not None:
            self.i_67 = self.get_pit0()
            #used_options.append("Hb Deoxy or Re-Oxy")
            if temp == "Deoxy" or temp == "Re-Oxy":
                if temp == "Re-Oxy":
                    self.set_pit0(7.2)
                elif temp == "Deoxy":
                    self.set_pit0(7.5)
                else:
                    self.set_pit0(7.2)

                self.cell.setpH(self.get_pit0() - self.i_67 + self.cell.getpH())
                self.cell.H.setConcentration(10.0 ** -self.cell.getpH())
                self.i_74 = self.get_pit0() - 0.016 * self.temperature
                if temp == "Re-Oxy":
                    self.set_atp(self.get_atp() * 2.0)
                    self.set_dpgp(self.get_dpgp() * 1.7)
                    self.cell.Mgf.setConcentration(eq_solver.newton_raphson(runner=eqmg_instance,
                                                                            initial=0.02,
                                                                            step=1.0E-4,
                                                                            stop=1.0E-5,
                                                                            max_its=100,
                                                                            initial_its=0,
                                                                            verbose=False))
                    self.A_10 = self.nXdefOxy
                elif temp == "Deoxy":
                    self.set_atp(self.get_atp() / 2.0)
                    self.set_dpgp(self.get_dpgp() / 1.7)
                    self.cell.Mgf.setConcentration(
                        eq_solver.newton_raphson(runner=eqmg_instance,
                                                 initial=0.02,
                                                 step=1.0E-4,
                                                 stop=1.0E-5,
                                                 max_its=100,
                                                 initial_its=0,
                                                 verbose=False))
                    self.A_10 = self.nXdefOxy - self.mgbal

    def fluxesRS(self):
        print("Starting FluxesRs")

        # Compute the permeabilities for Na pump and set fluxes
        self.npu.compute_permeabilities()
        self.npu.set_flux_net()
        self.npu.set_flux_K()

        # Calculate and set carrier-mediated fluxes
        flux_net = self.npu.get_flux_net()
        self.cme.set_flux_Na(-(1.0 - self.fG) * flux_net)

        self.cme.set_flux_K(-self.cme.get_flux_Na() / self.Na_to_K)

        self.cme.compute_permeabilities()

        # Calculate and set Goldman fluxes
        fal = self.cme.get_flux_Na() + self.cme.get_flux_K()
        self.gold.setFlux_A(-fal)
        self.gold.setFlux_Na(-self.fG * flux_net)

        self.gold.setFlux_K(-self.gold.getFlux_Na() / self.Na_to_K)

        # Set and compute Goldman permeabilities
        self.i_18 = 1.0
        self.gold.compute_permeabilities(self.Em, self.temperature)

        # Compute cotransport fluxes and other operations
        self.cot.compute_zero_factor()

        self.cot.compute_flux(self.i_18)

        # Call additional methods
        self.totalionfluxes()
        self.chbetc()

    def start_piezo(self):
        print("START PIEZO")
        try:
            # Define instances inside the method

            # Set old cycles and update cycle count
            self.piezo.set_old_cycles(self.cycles_per_print)
            self.cycles_per_print = self.piezo.get_cycles()
            logging.debug(f"Before updating cycle_count: {self.cycle_count}, cycles_per_print: {self.cycles_per_print}")
            self.cycle_count = self.cycles_per_print - 1
            logging.debug(f"After updating cycle_count: {self.cycle_count}")

            # Update permeabilities using PiezoGoldman
            self.pgold.set_permeability_K(self.piezo.get_pkg())
            self.pgold.set_permeability_Na(self.piezo.get_pnag())
            self.pgold.set_permeability_A(self.piezo.get_pag())

            # Set calcium permeability
            self.p_pass_ca.set_fcalm(self.piezo.get_pcag())

            # Update calcium pump settings
            self.piezo.set_old_pmca(self.cpu.get_fcapm())
            fac = (100.0 - self.piezo.get_pmca()) / 100.0
            self.cpu.set_fcapm(self.cpu.get_default_fcapm() * fac)

            # Update integration interval factor
            self.piezo.set_old_if(self.integration_interval_factor)
            self.integration_interval_factor = self.piezo.get_i_f()
            #print(self.piezo.get_i_f())

            # Update Jacobs-Stewart permeability
            jsfactor = self.piezo.get_piezo_js()
            self.oldJSPermeability = self.jstu.get_permeability()
            self.jstu.set_permeability(self.jstu.get_default_permeability() * jsfactor)

            # Update fraction and related parameters
            pfraction = self.piezo.get_piezo_fraction()
            if self.A_7 != pfraction:
                self.A_7 = pfraction
                self.A_8 = self.A_7 / (1.0 - self.A_7)

        except Exception as e:
            logging.error(f"An error occurred in start_piezo: {e}")

    def stop_piezo(self):
        print("STOP PIEZO")
        try:
            # Define instances inside the method

            # Get final flux values
            self.finalPiezoFK = self.pgold.get_flux_K()
            self.finalPiezoFNa = self.pgold.get_flux_Na()
            self.finalPiezoFA = self.pgold.get_flux_A()
            self.finalPiezoFCa = self.cpu.get_flux_ca()

            # Update cycle count
            self.cycle_count = self.cycles_per_print - 1

            # Reset permeabilities
            self.pgold.set_permeability_K(0.0)
            self.pgold.set_permeability_Na(0.0)
            self.pgold.set_permeability_A(0.0)

            # Final hematocrit and calcium concentration
            self.finalPiezoHct = self.fraction * 100.0
            self.finalPiezoCCa = self.cell.Cat.getConcentration()

            # Final results
            # self.final_piezo_result = self.make_result_hash()

            # Reset passive calcium and calcium pump
            self.p_pass_ca.set_fcalm(0.0)
            self.cpu.set_fcapm(self.piezo.get_old_pmca())

            # Restore original Jacobs-Stewart permeability
            self.js.set_permeability(self.oldJSPermeability)

            # Reset fraction and related parameters
            self.fraction = self.defaultFraction
            if self.A_7 != self.fraction:
                self.A_7 = self.fraction
                self.A_8 = self.A_7 / (1.0 - self.A_7)

            # Restore medium if needed
            if self.piezo.get_restore_medium():
                self.restore_medium()
                #self.publish()

        except Exception as e:
            logging.error(f"An error occurred in stop_piezo: {e}")

    def get_final_piezo_result(self):
        return self.final_piezo_result

    def get_final_piezo_hct(self):
        return self.final_piezo_hct

    def get_final_piezo_cc(self):
        return self.final_piezo_cc

    def end_piezo(self):
        print("END PIEZO")
        self.set_cycles_per_print(self.piezo.get_cycles())
        # print(self.piezo.get_old_cycles())
        self.cycle_count = self.get_cycles_per_print() - 1
        self.integration_interval_factor = self.piezo.get_old_if()

    def get_default_fraction(self):
        return self.defaultFraction

    def handle_piezo_operations(self):
        if self.sampling_time >= self.p_start and not self.piezo_started:
            self.start_piezo()
            print(f"p_start: {self.p_start}")
            self.piezo_started = True
        elif self.sampling_time >= self.p_stop and not self.piezo_stopped:
            self.stop_piezo()
            self.piezo_stopped = True
        elif self.sampling_time >= self.p_end and not self.piezo_ended:
            self.end_piezo()
            self.piezo_ended = True

    def compute_fluxes(self):
        self.npu.compute_flux()
        self.i_18 = math.exp((36.999 - self.temperature) / 10.0 * math.log(self.Q10Passive))
        self.cme.compute_flux()
        self.cot.compute_flux(self.i_18)
        self.jstu.compute_flux(self.i_18)

        eq_solver = EqSolver(self.atp, self.dpgp, self.vv, self.get_vw(), self.get_mgb0(), self.cell, self.medium,
                             self.buffer_conc, self.A_5, self.A_8, self.lig_hb, self.delta_H, self.dedgh)
        conc = ComputeAllFluxes(i_18=self.i_18, temperature=self.temperature, medium=self.medium, cell=self.cell,
                                Em=self.Em)

        self.Em = eq_solver.newton_raphson(conc, self.Em, 0.001, 1.0e-4, 100, 0, False)
        self.totalionfluxes()

        self.wtflux.compute_flux(self.fHb, self.get_cbenz2(), self.edgto, self.i_18, self.buffer_conc)

    def update_environment(self): #JAVA - part of UPDATECONTENT
        self.compute_deltas()
        self.update_contents()

        vw = self.get_vw()
        if vw != 0:
            self.cell.Cat.setConcentration(self.cell.Cat.getAmount() / vw)
            self.set_cbenz2(self.get_benz2() / vw)
        else:
            # Handle the case where vw is zero. You could set a default value or raise an exception.
            self.cell.Cat.setConcentration(0.0)
            self.set_cbenz2(0.0)
            # Alternatively, you can raise an exception if vw should never be zero
            # raise ValueError("Volume (vw) cannot be zero.")

        self.chbetc()

        medium_A_concentration = self.medium.A.getConcentration()
        cell_A_concentration = self.cell.A.getConcentration()
        if cell_A_concentration != 0:
            self.rA = medium_A_concentration / cell_A_concentration
        else:
            # Handle the case where cell A concentration is zero
            self.rA = float('inf')  # or 0, or any default value
            # Alternatively, raise an exception
            # raise ValueError("Cell A concentration cannot be zero.")

        medium_H_concentration = self.medium.H.getConcentration()
        cell_H_concentration = self.cell.H.getConcentration()
        if medium_H_concentration != 0:
            self.rH = cell_H_concentration / medium_H_concentration
        else:
            # Handle the case where medium H concentration is zero
            self.rH = float('inf')  # or 0, or any default value
            # Alternatively, raise an exception
            # raise ValueError("Medium H concentration cannot be zero.")

    def check_termination_conditions(self) -> bool:
        return self.get_vw() > self.get_vlysis()

    #  def handle_gluconate_adjustment(self):
    #     if self.I_73 > 0.0 and self.T_6 > 0.0 and self.sampling_time * 60.0 > self.T_6:
    #        self.medium.Gluconate.setConcentration(self.medium.Gluconate.getConcentration() - self.I_73)
    #      self.medium.A.setConcentration(self.medium.A.getConcentration() + self.I_73)
    #       self.I_73 = 0.0

    def runall(self):
        self.cycle_count = 0
        self.n_its = 0
        self.p = True
        if self.p:
            self.p_start = self.piezo.get_start_time()
            self.p_stop = self.p_start + self.piezo.get_duration()
            self.p_end = min(self.p_stop + self.piezo.get_recovery(), self.duration_experiment / 60.0 - 1e-6)
            #print(self.p_start, self.p_stop, self.p_end)

        end_time = self.duration_experiment * 60.0  # Convert duration_experiment to minutes

        while self.sampling_time * 60 <= self.duration_experiment:
            if self.sampling_time == end_time:
                print(f"Sampling time: {self.sampling_time}, duration {end_time}")
                break
            #print(f"Sampling time: {self.sampling_time}, duration {self.duration_experiment}")

            self.handle_piezo_operations()
            self.compute_fluxes()


            # Calculate the integration interval
            self.calculate_integration_interval()
            self.update_environment()
            print(f"Delta:{self.delta_Na}")

            self.record_results()

            if self.check_termination_conditions():
                break

            if self.i_73 > 0.0 and 0.0 < self.T_6 < self.sampling_time * 60.0:
                self.medium.Gluconate.setConcentration(self.medium.Gluconate.getConcentration() - self.i_73)
                self.medium.A.setConcentration(self.medium.A.getConcentration() + self.i_73)
                self.i_73 = 0.0

            # Compute fluxes and update environment

            self.total_cycle_count += 1

            # Update sampling time
        self.finalize_results()

    def calculate_integration_interval(self): #JAVA - part of UPDATECONTENT
        print('Starting integration interval calculation...')
        i_23 = self.calculate_i_23()
        if self.get_compute_delta_time:
            self.delta_time = self.integration_interval_factor / i_23
        else:
            temp = self.integration_interval_factor / i_23
            if temp < self.fixed_delta_time:
                self.delta_time = self.fixed_delta_time

        self.delta_time = 0.01

        self.update_sampling_time()

        #print(f"Delta Time: {self.delta_time}")

    def update_sampling_time(self):
        self.sampling_time += self.delta_time
        self.cycle_count += 1
        self.n_its += 1

    def calculate_i_23(self) -> float:
        return (10.0 +
                10.0 * abs(self.a23.get_flux_Mg() + self.total_flux_Ca) +
                abs(self.gold.getFlux_H() + self.pgold.get_flux_H()) +
                abs(self.dedgh) +
                abs(self.total_flux_Na) +
                abs(self.total_flux_K) +
                abs(self.total_flux_A) +
                abs(self.total_flux_H) +
                abs(self.wtflux.getFlux() * 100.0))

    def should_record_results(self) -> bool:
        return self.cycle_count >= self.cycles_per_print

    def get_combined_state(self) -> Dict[str, float]: #JAVA - MakeResultHash
        def safe_log(x):
            """Safely computes the natural logarithm of x, handling cases where x <= 0."""
            if x <= 0:
                # Handle the case where x is zero or negative.
                return float('-inf')  # or use a large negative number, or another strategy.
            else:
                return math.log(x)

        # Get current state
        current_state = {
            'time': self.sampling_time,
            'V/V': self.vv,
            "Vw": self.get_vw(),
            "Hb_Concentration": self.cell.Hb.getConcentration(),
            "fHb": self.fHb,
            "Na_Amount": self.cell.Na.getAmount(),
            "K_Amount": self.cell.K.getAmount(),
            "A_Amount": self.cell.A.getAmount(),
            "NetChargeHb": self.netChargeHb,
            "pHi": self.cell.getpH(),
            "Density": (self.get_hb_content() / 100.0 + self.get_vw()) / self.vv,
            "Fraction": self.A_7 * self.vv,
            "Medium_Na_Concentration": self.medium.Na.getConcentration(),
            "Medium_K_Concentration": self.medium.K.getConcentration(),
            "Medium_A_Concentration": self.medium.A.getConcentration(),
            "Medium_Gluconate_Concentration": self.medium.Gluconate.getConcentration(),
            "Medium_Glucamine_Concentration": self.medium.Glucamine.getConcentration(),
            "Medium_Sucrose_Concentration": self.medium.Sucrose.getConcentration(),
            "Buffer_Conc": self.buffer_conc,
            "Medium_Hb_Concentration": self.medium.Hb.getConcentration(),
            "Medium_Mgt_Concentration": self.medium.Mgt.getConcentration(),
            "Medium_Cat_Concentration": self.medium.Cat.getConcentration(),
            "Edgto": self.edgto,
            "pH_Medium": self.medium.getpH(),
            "Na_Concentration_Cell": self.cell.Na.getConcentration(),
            "K_Concentration_Cell": self.cell.K.getConcentration(),
            "A_Concentration_Cell": self.cell.A.getConcentration(),
            "Mgf_Concentration": self.cell.Mgf.getConcentration(),
        }

        # Calculate additional results
        rtoverf = self.gold.getRtoverf()
        additional_results = {
            "EA": -rtoverf * safe_log(
                self.safe_division(self.medium.A.getConcentration(), self.cell.A.getConcentration())),
            "EH": rtoverf * safe_log(
                self.safe_division(self.medium.H.getConcentration(), self.cell.H.getConcentration())),
            "EK": rtoverf * safe_log(
                self.safe_division(self.medium.K.getConcentration(), self.cell.K.getConcentration())),
            "ENa": rtoverf * safe_log(
                self.safe_division(self.medium.Na.getConcentration(), self.cell.Na.getConcentration())),
            "FKGgardos": self.gold.computeFKGardos(self.i_18),
            "FzK": self.pgold.get_flux_K(),
            "FzNa": self.pgold.get_flux_Na(),
            "FzA": self.pgold.get_flux_A(),
            "FzCa": self.p_pass_ca.get_flux(),
            "FClCo": self.cot.get_flux_A(),
            "FKCo": self.cot.get_flux_K(),
            "FNaCo": self.cot.get_flux_Na(),
            "fHb*CHb": self.fHb * self.cell.Hb.getConcentration(),
            "nHb*CHb": self.nHb * self.cell.Hb.getConcentration(),
            "TransitHct": self.finalPiezoHct,
            "FzKGTransit": self.finalPiezoFK,
            "FzNaGTransit": self.finalPiezoFNa,
            "FzAGTransit": self.finalPiezoFA,
            "FzCaGTransit": self.finalPiezoFCa,
            "EN test": (
                    self.total_flux_Na +
                    self.total_flux_K +
                    self.total_flux_H -
                    self.total_flux_A +
                    2.0 * (self.total_flux_Ca + self.a23.get_flux_Mg())
            ),
            'CVF': self.fraction,
            'Hct': self.fraction * 100.0,
            'Em': self.Em,
            'QCa': self.cell.Cat.getAmount(),
            'QMg': self.cell.Mgt.getAmount(),
            'CH/nM': 1.0E9 * 10.0 ** (-self.cell.getpH()),
            'CCa2+': self.cell.Caf.getConcentration(),
            'MCHC': self.mchc,
            'Temp (°C)': self.temperature,
        }

        # Combine both dictionaries
        combined_state = {**current_state, **additional_results}
        return combined_state

    def finalize_results(self, csv_file_path='/Users/laurafreneda/Documents/test2_py.csv') -> np.ndarray: #ATTEMPT TO SAVEEVERYTHING ON A FILE
        # Define dtype with column names and corresponding data types
        dtype = [('time', float), ('Vw', float), ('V/V', float), ('Hb_Concentration', float), ('fHb', float),
                 ('Na_Amount', float), ('K_Amount', float), ('A_Amount', float), ('NetChargeHb', float),
                 ('pHi', float), ('Density', float), ('Fraction', float), ('Medium_Na_Concentration', float),
                 ('Medium_K_Concentration', float), ('Medium_A_Concentration', float),
                 ('Medium_Gluconate_Concentration', float), ('Medium_Glucamine_Concentration', float),
                 ('Medium_Sucrose_Concentration', float), ('Buffer_Conc', float),
                 ('Medium_Hb_Concentration', float), ('Medium_Mgt_Concentration', float),
                 ('Medium_Cat_Concentration', float), ('Edgto', float), ('pH_Medium', float),
                 ('Na_Concentration_Cell', float), ('K_Concentration_Cell', float),
                 ('A_Concentration_Cell', float), ('Mgf_Concentration', float),
                 ('EA', float), ('EH', float), ('EK', float), ('ENa', float),
                 ('FKGgardos', float), ('FzK', float), ('FzNa', float), ('FzA', float),
                 ('FzCa', float), ('FClCo', float), ('FKCo', float), ('FNaCo', float),
                 ('fHb*CHb', float), ('nHb*CHb', float), ('TransitHct', float),
                 ('FzKGTransit', float), ('FzNaGTransit', float), ('FzAGTransit', float),
                 ('FzCaGTransit', float), ('EN test', float), ('CVF', float), ('Hct', float),
                 ('Em', float), ('QCa', float), ('QMg', float), ('CH/nM', float), ('CCa2+', float),
                 ('MCHC', float), ('Temp (°C)', float), ('Iteration', int)]

        # Convert results to structured array for CSV export
        try:
            # Convert results to a structured array for CSV export
            structured_array = np.array([tuple(d[name] for name, _ in dtype) for d in self.results], dtype=dtype)

            # Check if the CSV file already exists
            file_exists = os.path.isfile(csv_file_path)

            with open(csv_file_path, mode='a', newline='') as csv_file:
                writer = csv.writer(csv_file)

                # If the file doesn't exist, write the header
                if not file_exists:
                    writer.writerow([name for name, _ in dtype])

                # Write the data rows
                for row in structured_array:
                    writer.writerow(row)

            self.record_results()

            return structured_array
        except Exception as e:
            print(f"Error finalizing results: {e}")
            return np.array([], dtype=dtype)

    def record_results(self):
        try:
            results = self.get_combined_state()
            results['Iteration'] = self.total_cycle_count
            self.results.append(results)
            self.total_cycle_count += 1
            print(f"Recorded cycle {self.total_cycle_count}")
        except Exception as e:
            print(f"Error recording results: {e}")

    def get_results(self):
        try:
            # self.results_df = pd.DataFrame(self.results)
            return pd.DataFrame(self.results)
        except Exception as e:
            print(f"Error getting results: {e}")
            return pd.DataFrame()  # Return empty DataFrame on error

    def setup(self, options):
        if self.stage == 0:
            # Example of processing options from the dictionary
            self.na_pump_screen_rs(options)
            self.cellwater_screen_rs(options)
            self.cellanionproton_screen_rs(options)
            self.chargeandpi_screen_rs(options)
            print("Setting up the RS")

            # Setting default values if not provided in options
            self.set_cycles_per_print(11)
            #options['cycles_per_print'] = self.get_cycles_per_print()  # Update options with the value set

            self.set_vw(self.get_i_79())
            print(f"setup vw {self.get_vw()}")
            #self.set_vw(options.get('vw', self.get_i_79()))
            #options['vw'] = self.get_vw()  # Update options with the value set

            self.fraction = 1.0e-4
            #options['fraction'] = self.fraction  # Update options with the value set

            self.defaultFraction = 1.0e-4
            #options['default_fraction'] = self.defaultFraction  # Update options with the value set

            self.medium.setpH(7.4)
            #options['medium_pH'] = self.medium.getpH()  # Update options with the value set

            self.A_11 = 1.0 - (self.get_hb_content() / 136.0)
            #options['A_11'] = self.A_11  # Update options with the value set

            self.sampling_time = 0.0

            self.set_mg_defaults()
            #options['mg_defaults'] = self.get_mg_defaults()  # If needed, add an update for mg_defaults

            self.setcadefaults()
            #options['cadefaults'] = self.get_cadefaults()  # If needed, add an update for cadefaults

            self.mgbufferscreenRS()
            # options['mg_buffer'] = self.get_mg_buffer()  # If needed, add an update for mg_buffer

            self.cabufferscreenRS(options)
            # options['ca_buffer'] = self.get_ca_buffer()  # If needed, add an update for ca_buffer

            # Compute RS
            self.computeRS()

            print("Setup finished")

    def setupDS(self, piezo_options, options):
        print("Setting up the DS")

        # Process options from the dictionary
        self.set_screen_time_factor_options()
        self.set_cell_fraction_options(options)
        #self.set_transport_changes_options(options.get('transport_changes', {}))
        self.set_temp_permeability_options(piezo_options)
        self.set_piezo_options(piezo_options)
        # fraction_used_options = self.set_cell_fraction_options(used_options)
        #permeability_used_options = self.set_temp_permeability_options(used_options)
        #piezo_used_options = self.set_piezo_options(used_piezo_options)

        #$all_options = ['Time', 'Accuracy', 'FrequencyFactor', 'Regular dt', 'dt', 'CyclesPerPrint', 'piezo_options']

        # if self.verbose:
        #    print("\nUsed DS options")
        #   for option in used_optionsDS:
        #      print(option)

        # print("\nUnused DS options")
        # for option in all_options:
        #    if option not in used_optionsDS:
        #       print(option)
        #      print(f"Didn't recognize {option} for DS - tell Simon!")

        self.stage += 1
        print(f"Setup DS, stage = {self.stage}")

        #  for option in all_options:
        #     if option not in used_optionsDS:
        # print(f"Not used: {option}")

        return options, piezo_options

    def chelator(self):
        self.medium.Na.setConcentration(
            self.medium.Na.getConcentration() + 2.0 * self.edgto
        )

    def safe_division(self, numerator, denominator):
        # Check if either the numerator or denominator is zero
        if numerator == 0 or denominator == 0:
            return 0.0
        else:
            return numerator / denominator

    def set_screen_time_factor_options(self):
        # Default values and settings
        regular_dt = "yes"

        # Setting Time
        Time = 5.0
        self.set_duration_experiment(Time)
        #options["Time"] = Time  # Update options with the value set

        # Setting Accuracy
        Accuracy = 4
        self.dp = int(Accuracy)
        #options["Accuracy"] = Accuracy  # Update options with the value set

        # Setting FrequencyFactor
        FrequencyFactor = 0.001
        self.set_i_43(self.get_integration_interval_factor())
        self.set_integration_interval_factor = float(FrequencyFactor)
        #options["FrequencyFactor"] = FrequencyFactor  # Update options with the value set

        # Setting compute_delta_time based on regular_dt
        if regular_dt == "no":
            self.compute_delta_time = False
        elif regular_dt == "yes":
            self.compute_delta_time = True
        else:
            print("Invalid value for field compute_delta_time")
        #options["regular_dt"] = regular_dt  # Update options with the value set

        # Setting dt
        dt = 0.1 / 3600
        self.set_delta_time(float(dt))
        #options["dt"] = dt  # Update options with the value set

        # Setting CyclesPerPrint
        self.set_cycles_per_print(777)
        #options["CyclesPerPrint"] = self.get_cycles_per_print()  # Update options with the value set

    def oldedgta(self):
        h_conc = self.medium.H.getConcentration()
        edghk1 = self.edghk1
        edghk2 = self.edghk2
        edgto = self.edgto

        # Perform the calculations using safe division
        fh = 1.0 + self.safe_division(numerator=h_conc, denominator=edghk1) + self.safe_division(numerator=h_conc ** 2,
                                                                                                 denominator=edghk1 * edghk2)

        edg4old = self.safe_division(numerator=edgto, denominator=1000.0) * fh

        edg3old = edg4old * self.safe_division(numerator=h_conc, denominator=edghk1)

        edg2old = edg4old * self.safe_division(numerator=h_conc ** 2, denominator=edghk1 * edghk2)

        self.edghold = edg3old + 2.0 * edg2old
        self.edghold *= 1000.0

        # Additional method calls
        self.edgtainitial()
        self.edgta()

        # Calculate edgneg using safe division where needed
        self.edgneg = 2.0 * self.edg2 + 3.0 * self.edg3 + 4.0 * self.edg4 + 2.0 * (self.edgca + self.edgmg)

        self.medium.Na.setConcentration(
            self.medium.A.getConcentration() +
            self.edgneg +
            self.medium.Gluconate.getConcentration() +
            self.buffer_conc -
            self.medium.Hb.getConcentration() -
            self.medium.Glucamine.getConcentration() -
            self.medium.K.getConcentration() -
            2.0 * self.medium.Mgf.getConcentration() -
            2.0 * self.medium.Caf.getConcentration())

    def get_i_79(self):
        return self.i_79

    def set_i_79(self, value):
        self.i_79 = value

    def chbetc(self) -> None:
        vw = self.get_vw()

        if vw == 0.0:

            self.cell.Hb.setConcentration(0.0)
            self.cell.Mgt.setConcentration(0.0)
            self.cell.X.setConcentration(0.0)

            x_amount = self.cell.X.getAmount()
            self.cell.XHbm.setAmount(self.netChargeHb + self.A_10 * x_amount - 2.0 * self.get_benz2())
            self.cell.XHbm.setConcentration(0.0)

            self.cell.COs.setConcentration(0.0)
            self.cell.Hbpm.setConcentration(0.0)

        else:
            # Setting concentrations

            self.cell.Hb.setConcentration(self.cell.Hb.getAmount() / vw)
            self.cell.Mgt.setConcentration(self.cell.Mgt.getAmount() / vw)
            self.cell.X.setConcentration(self.cell.X.getAmount() / vw)

            x_amount = self.cell.X.getAmount()
            self.cell.XHbm.setAmount(self.netChargeHb + self.A_10 * x_amount - 2.0 * self.get_benz2())
            self.cell.XHbm.setConcentration(self.cell.XHbm.getAmount() / vw)

            self.cell.COs.setConcentration(self.fHb * self.cell.Hb.getAmount() / vw)
            self.cell.Hbpm.setConcentration(self.nHb * self.cell.Hb.getAmount() / vw)

        # Medium concentrations
        medium_concentration = (
                self.medium.Na.getConcentration() +
                self.medium.K.getConcentration() +
                self.medium.A.getConcentration() +
                self.buffer_conc +
                self.medium.Gluconate.getConcentration() +
                self.medium.Glucamine.getConcentration() +
                self.medium.Sucrose.getConcentration() +
                self.medium.Mgf.getConcentration() +
                self.medium.Caf.getConcentration() +
                self.edgto
        )
        self.medium.Os.setConcentration(medium_concentration)

        # Cell amounts
        cell_amount = (
                self.cell.Na.getAmount() +
                self.cell.K.getAmount() +
                self.cell.A.getAmount() +
                self.fHb * self.cell.Hb.getAmount() +
                self.cell.X.getAmount() +
                self.cell.Mgt.getAmount() +
                (self.cell.Mgf.getConcentration() + self.cell.Caf.getConcentration()) * vw +
                self.get_benz2()
        )
        self.cell.Os.setAmount(cell_amount)

        # Cell concentrations
        cell_concentration = (
                self.cell.Na.getConcentration() +
                self.cell.K.getConcentration() +
                self.cell.A.getConcentration() +
                self.fHb * self.cell.Hb.getConcentration() +
                self.cell.X.getConcentration() +
                self.cell.Mgf.getConcentration() +
                self.cell.Caf.getConcentration() +
                self.get_cbenz2()
        )
        self.cell.Os.setConcentration(cell_concentration)

    def totalionfluxes(self):

        self.total_flux_Na = (
                self.npu.get_flux_net() +
                self.cme.get_flux_Na() +
                self.gold.getFlux_Na() +
                self.pgold.get_flux_Na() +
                self.cot.get_flux_Na()
        )

        self.total_flux_K = (
                self.npu.get_flux_K() +
                self.cme.get_flux_K() +
                self.gold.getFlux_K() +
                self.pgold.get_flux_K() +
                self.cot.get_flux_K()
        )

        self.total_flux_A = (
                self.gold.getFlux_A() +
                self.pgold.get_flux_A() +
                self.cot.get_flux_A() +
                self.jstu.get_flux_A() +
                self.cme.get_flux_Na() +
                self.cme.get_flux_K()
        )

        self.total_flux_H = (
                self.jstu.get_flux_H() +
                self.gold.getFlux_H() +
                self.pgold.get_flux_H() -
                2.0 * self.a23.get_flux_Mg() -
                2.0 * self.a23.get_flux_Ca() +
                self.cpu.get_flux_h()
        )

    def update_contents(self):
        # Initialize data dictionary to store the outputs

        # Collect data before modifications
        Vw_old = self.get_vw()
        self.data["Vw_old"].append(Vw_old)

        self.totalionfluxes()
        self.compute_deltas()

        self.set_vw(self.get_vw() + self.delta_Water)
        print(f"upcont vw,delta water {self.get_vw(),self.delta_Water}")
        self.data["Vw"].append(self.get_vw())

        if self.get_vw() == 0 or self.cell.Hb.getAmount() == 0:
            self.cell.Hb.setConcentration(0.0)
        else:
            self.cell.Hb.setConcentration(self.cell.Hb.getAmount() / self.get_vw())

        self.fHb = 1.0 + self.A_2 * self.cell.Hb.getConcentration() + self.A_3 * (self.cell.Hb.getConcentration() ** 2)
        self.data["Hb_Concentration"].append(self.cell.Hb.getConcentration())
        self.data["fHb"].append(self.fHb)

        self.cell.Na.setAmount(self.cell.Na.getAmount() + self.delta_Na)
        self.data["Na_Amount"].append(self.cell.Na.getAmount())

        self.cell.K.setAmount(self.cell.K.getAmount() + self.delta_K)
        self.data["K_Amount"].append(self.cell.K.getAmount())

        self.cell.A.setAmount(float(self.cell.A.getAmount() + self.delta_A))
        self.data["A_Amount"].append(self.cell.A.getAmount())

        self.netChargeHb = float(self.netChargeHb + self.delta_H)
        self.data["NetChargeHb"].append(self.netChargeHb)

        self.nHb = self.netChargeHb /self.cell.Hb.getAmount()

        pinew = self.pit0 - 0.016 * self.temperature
        self.i_74 = pinew
        self.cell.setpH(self.i_74 + self.nHb / self.A_1)
        self.cell.H.setConcentration(10.0 ** (-self.cell.getpH()))
        self.nHb = self.A_1 * (self.cell.getpH() - self.i_74)
        self.data["pHi"].append(self.cell.getpH())

        self.vv = 1.0 - self.A_11 + self.get_vw()
        self.data["Density"].append((self.get_hb_content() / 100.0 + self.get_vw()) / self.vv)
        self.data["Fraction"].append(self.A_7 * self.vv)

        self.mchc = self.get_hb_content()/self.vv

        i_30 = 1.0 + (self.get_vw() - Vw_old) * self.A_8
        self.medium.Na.setConcentration(self.medium.Na.getConcentration() * i_30 - self.delta_Na * self.A_8)
        self.data["Medium_Na_Concentration"].append(self.medium.Na.getConcentration())

        self.medium.K.setConcentration(self.medium.K.getConcentration() * i_30 - self.delta_K * self.A_8)
        self.data["Medium_K_Concentration"].append(self.medium.K.getConcentration())

        self.medium.A.setConcentration(self.medium.A.getConcentration() * i_30 - self.delta_A * self.A_8)
        self.data["Medium_A_Concentration"].append(self.medium.A.getConcentration())

        self.medium.Gluconate.setConcentration(self.medium.Gluconate.getConcentration() * i_30)
        self.data["Medium_Gluconate_Concentration"].append(self.medium.Gluconate.getConcentration())

        self.medium.Glucamine.setConcentration(self.medium.Glucamine.getConcentration() * i_30)
        self.data["Medium_Glucamine_Concentration"].append(self.medium.Glucamine.getConcentration())

        self.medium.Sucrose.setConcentration(self.medium.Sucrose.getConcentration() * i_30)
        self.data["Medium_Sucrose_Concentration"].append(self.medium.Sucrose.getConcentration())

        self.buffer_conc *= i_30
        self.data["Buffer_Conc"].append(self.buffer_conc)

        self.medium.Hb.setConcentration(self.medium.Hb.getConcentration() * i_30)
        self.data["Medium_Hb_Concentration"].append(self.medium.Hb.getConcentration())

        self.medium.Mgt.setConcentration(self.medium.Mgt.getConcentration() * i_30 - self.delta_Mg * self.A_8)
        self.data["Medium_Mgt_Concentration"].append(self.medium.Mgt.getConcentration())

        self.medium.Cat.setConcentration(self.medium.Cat.getConcentration() * i_30 - self.delta_Ca * self.A_8)
        self.data["Medium_Cat_Concentration"].append(self.medium.Cat.getConcentration())

        self.edgto *= i_30
        self.data["Edgto"].append(self.edgto)

        if self.edgto == 0.0:
            self.medium.Mgf.setConcentration(self.medium.Mgt.getConcentration())
            self.medium.Caf.setConcentration(self.medium.Cat.getConcentration())

        self.medium.Hb.setConcentration(self.medium.Hb.getConcentration() * i_30 - self.delta_H * self.A_8)
        self.data["Medium_Hb_Concentration"].append(self.medium.Hb.getConcentration())
        self.medium.H.setConcentration(
            self.A_5 * self.medium.Hb.getConcentration() / (self.buffer_conc - self.medium.Hb.getConcentration()))
        if self.medium.H.getConcentration() < 1.0E-10:
            self.medium.H.setConcentration(1.0E-10)
        self.medium.setpH(-math.log10(self.medium.H.getConcentration()))
        self.data["pHo"].append(self.medium.getpH())

        if math.isnan(self.medium.getpH()):
            print(f"Warning: pH = NaN, Buffer conc = {self.medium.H.getConcentration()}")

        if self.get_vw() == 0:
            self.cell.Na.setConcentration(0.0)
            self.cell.K.setConcentration(0.0)
            self.cell.A.setConcentration(0.0)
        else:
            self.cell.Na.setConcentration(self.cell.Na.getAmount() / self.get_vw())
            self.data["Na_Concentration_Cell"].append(self.cell.Na.getConcentration())

            self.cell.K.setConcentration(self.cell.K.getAmount() / self.get_vw())
            self.data["K_Concentration_Cell"].append(self.cell.K.getConcentration())

            self.cell.A.setConcentration(self.cell.A.getAmount() / self.get_vw())
            self.data["A_Concentration_Cell"].append(self.cell.A.getConcentration())

        eq_solver = EqSolver(self.atp, self.dpgp, self.vv, self.get_vw(), self.get_mgb0(), self.cell, self.medium,
                             self.buffer_conc, self.A_5, self.A_8, self.lig_hb, self.delta_H, self.dedgh)

        eqmg_instance = Eqmg(buffer_conc=self.buffer_conc, delta_H=self.delta_H,
                             lig_hb=self.lig_hb, A_8=self.A_8, dedgh=self.dedgh, atp=self.atp,
                             mgb0=self.get_mgb0(), vw=self.get_vw(), vv=self.vv, Mgt_Amount=self.cell.Mgt.getAmount(),
                             dpgp=self.get_dpgp(), local_mgf=self.cell.Mgf.getConcentration())

        conc = eq_solver.newton_raphson(runner=eqmg_instance,
                                        initial=0.02,
                                        step=1.0E-4,
                                        stop=1.0E-5,
                                        max_its=100,
                                        initial_its=0,
                                        verbose=False)

        self.cell.Mgf.setConcentration(conc)
        self.data["Mgf_Concentration"].append(self.cell.Mgf.getConcentration())

        self.canr()

        # Convert dictionary to self.dataFrame and save to CSV

    # df = pd.self.dataFrame(self.data)
    #df.to_csv('output_self.data.csv', index=False)

    def canr(self):
        # Define a scaling factor
        scale_factor = 1000.0

        # Scale up concentrations and amounts
        self._scale_values(scale_factor)

        eq_solver = EqSolver(self.atp, self.dpgp, self.vv, self.get_vw(), self.get_mgb0(), self.cell, self.medium,
                             self.buffer_conc, self.A_5, self.A_8, self.lig_hb, self.delta_H, self.dedgh)

        eqca_instance = Eqca(alpha=self.get_alpha(), vv=self.vv, b1ca=self.b1ca, b1cak=self.b1cak,
                             benz2=self.get_benz2(),
                             benz2k=self.benz2k, Cat_Amount=self.cell.Cat.getAmount(),
                             local_x6=self.cell.Caf.getConcentration())

        conc = eq_solver.newton_raphson(
            runner=eqca_instance,
            initial=self.cell.Caf.getConcentration(),
            step=1.0E-6,
            stop=1.0E-6,
            max_its=100,
            initial_its=0,
            verbose=False,
        )

        # Update Caf concentration with the solved value
        self.cell.Caf.setConcentration(conc)

        # Scale down concentrations and amounts
        self._scale_values(1.0 / scale_factor)

    def _scale_values(self, factor):
        """Helper method to scale values by a given factor."""
        self.cell.Caf.setConcentration(self.cell.Caf.getConcentration() * factor)
        self.cell.Cat.setAmount(self.cell.Cat.getAmount() * factor)
        self.set_b1ca(self.get_b1ca() * factor)
        self.set_b1cak(self.get_b1cak() * factor)
        self.set_benz2(self.get_benz2() * factor)
        self.benz2k *= factor

    def edgtainitial(self):
        """ Initialize EDG parameters and perform calculations. """
        # Convert concentrations and parameters from millimolar to molar.Adjust the concentrations of three
        # components (H, Caf, and Mgf)

        self.edgto /= 1000.0
        self.medium.Caf.setConcentration(self.medium.Caf.getConcentration() / 1000.0)
        self.medium.Mgf.setConcentration(self.medium.Mgf.getConcentration() / 1000.0)
        self.medium.Cat.setConcentration(self.medium.Cat.getConcentration() / 1000.0)
        self.medium.Mgt.setConcentration(self.medium.Mgt.getConcentration() / 1000.0)
        self.buffer_conc /= 1000.0
        self.delta_H /= 1000.0
        self.dedgh /= 1000.0

        # Compute the variable 'fff'
        H_conc = self.medium.H.getConcentration()
        Caf_conc = self.medium.Caf.getConcentration()
        Mgf_conc = self.medium.Mgf.getConcentration()

        fff = (1.0 + self.safe_division(H_conc, self.edghk1) +
               self.safe_division(H_conc ** 2, self.edghk1 * self.edghk2) +
               self.safe_division(Caf_conc, self.edgcak) +
               self.safe_division(Mgf_conc, self.edgmgk))

        # Compute 'lig_hb'
        self.lig_hb = (H_conc * self.safe_division(self.buffer_conc, (H_conc + self.A_5)) +
                       self.safe_division(self.edgto * self.edghk1, fff) +
                       self.safe_division(H_conc * self.edgto * self.edghk1 * self.edghk2, fff))

        lig = Ligs_eqs(self.medium, self.buffer_conc, self.A_5, self.lig_hb, self.delta_H)

        """Update the concentrations of ions using a Newton-Raphson approach."""

        nn = 0
        finished = False

        while not finished:
            # H concentration update
            H_conc = self.medium.H.getConcentration()
            hhold = H_conc
            self.it_counter = 0
            X_3 = lig.newton_raphson2(lig.ligeq1_run, H_conc, 1e-4 * H_conc, self.diff2, 100, 0, verbose=False)
            if X_3 < 0:
                X_3 = hhold
            self.medium.H.setConcentration(X_3)

            # Caf concentration update
            Caf_conc = self.medium.Caf.getConcentration()
            cafold = Caf_conc
            self.it_counter = 0
            X_3 = lig.newton_raphson2(lig.ligeq2_run, Caf_conc, 1e-4 * cafold, self.diff2, 100, 0, verbose=False)
            if X_3 < 0:
                X_3 = cafold / 2.0
            self.medium.Caf.setConcentration(X_3)

            # Mgf concentration update
            Mgf_conc = self.medium.Mgf.getConcentration()
            mgfold = Mgf_conc
            self.it_counter = 0
            X_3 = lig.newton_raphson2(lig.ligeq3_run, Mgf_conc, 1e-4 * mgfold, self.diff2, 100, 0, verbose=False)
            if X_3 < 0:
                X_3 = mgfold / 2.0
            self.medium.Mgf.setConcentration(X_3)

            nn += 1
            if nn > 100:
                finished = True

            # Check convergence
            if (abs(self.medium.H.getConcentration() - hhold) <= self.diff3 * hhold and
                    abs(cafold - self.medium.Caf.getConcentration()) <= self.diff3 * cafold and
                    abs(mgfold - self.medium.Mgf.getConcentration()) <= self.diff3 * mgfold):
                finished = True
        #print(f"Total iterations: {iteration_count}")
        #print(f"Total Newton-Raphson iterations: {total_newton_iterations}")
        # Final adjustments and computations
        #print(self.medium.H.getConcentration())
        self.medium.setpH(-math.log10(self.medium.H.getConcentration()))

        self.buffer_conc *= 1000.0
        self.delta_H *= 1000.0

        H_conc = self.medium.H.getConcentration()
        self.medium.Hb.setConcentration(self.safe_division(H_conc * self.buffer_conc, (H_conc + self.A_5)))
        if self.edgto == 0 or self.ff == 0:
            self.edg4 = 0
        else:
            self.edg4 = self.edgto / self.ff
        self.edg3 = self.safe_division(self.edg4 * H_conc, self.edghk1)
        self.edg2 = self.safe_division(self.edg4 * (H_conc ** 2), self.edghk1 * self.edghk2)
        self.edgca = self.safe_division(self.edg4 * Caf_conc, self.edgcak)
        self.edgmg = self.safe_division(self.edg4 * Mgf_conc, self.edgmgk)
        self.edgneg = (2.0 * self.edg2 + 3.0 * self.edg3 + 4.0 * self.edg4 +
                       2.0 * (self.edgca + self.edgmg))
        self.edghnew = self.edg3 + 2.0 * self.edg2

        # Convert back to millimolar
        self.edgto *= 1000.0
        self.medium.Caf.setConcentration(self.medium.Caf.getConcentration() * 1000.0)
        self.medium.Mgf.setConcentration(self.medium.Mgf.getConcentration() * 1000.0)
        self.medium.Cat.setConcentration(self.medium.Cat.getConcentration() * 1000.0)
        self.medium.Mgt.setConcentration(self.medium.Mgt.getConcentration() * 1000.0)
        self.edg4 *= 1000.0
        self.edg3 *= 1000.0
        self.edg2 *= 1000.0
        self.edgca *= 1000.0
        self.edgmg *= 1000.0
        self.edgneg *= 1000.0
        self.edghnew *= 1000.0
        self.dedgh = self.edghnew - self.edghold

    def edgta(self) -> None:
        self.edghold = self.edg3 + 2.0 * self.edg2
        self.edgtainitial()

    def restore_medium(self):
        self.buffer_conc = self.piezo.get_restore_hepes_na()
        self.medium.pH = self.piezo.get_restore_ph()
        self.medium.H.setConcentration(10 ** -self.medium.pH)
        self.medium.Hb.setConcentration(
            self.buffer_conc * self.medium.H.getConcentration() / (self.A_5 + self.medium.H.getConcentration()))

        if (na := self.piezo.get_restore_na()) > 0:
            self.medium.Na.setConcentration(na)
        if (k := self.piezo.get_restore_k()) > 0:
            self.medium.K.setConcentration(k)

        ca = self.piezo.get_restore_ca()
        mg = self.piezo.get_restore_mg()
        for attr in ['Caf', 'Cat']:
            getattr(self.medium, attr).setConcentration(ca)
        for attr in ['Mgf', 'Mgt']:
            getattr(self.medium, attr).setConcentration(mg)

    def compute_deltas(self):
        print(f'antessss wtflux compute self.data: {self.wtflux.getFlux()}')

        #print(f"AQUI ESTAO DELTA TIME {self.delta_time}")
        self.delta_Na = self.total_flux_Na * self.delta_time
        self.delta_K = self.total_flux_K * self.delta_time
        self.delta_A = self.total_flux_A * self.delta_time
        self.delta_H = self.total_flux_H * self.delta_time
        self.delta_Water = self.wtflux.getFlux() * self.delta_time
        print(f'depois ss wtflux compute self.data: {self.wtflux.getFlux()}')
        print(f'delta time: {self.delta_time}')
        self.delta_Mg = self.a23.get_flux_Mg() * self.delta_time
        self.delta_Ca = self.total_flux_Ca * self.delta_time

        #return delta_A, delta_Water, delta_K, delta_Na, delta_Ca, delta_Mg, delta_H

    def set_cell_fraction_options(self, options):
        #used_options = []

        # CVF
        temp = options.get("CVF")
        if temp is not None:
            self.fraction = float(temp)
            self.defaultFraction = self.fraction
            options["CVF"] = self.fraction
            #used_options.append("CVF")
            if self.A_7 != self.fraction:
                self.A_7 = self.fraction
                self.A_8 = self.A_7 / (1.0 - self.A_7)

        # BufferType (default to HEPES)
        self.BufferType = "HEPES"
        # Uncomment if you want to track this
        # options["buffer-name"] = self.BufferType

        # MB
        temp = options.get("MB")
        if temp is not None:
            self.buffer_conc = float(temp)
            options["MB"] = self.buffer_conc
            #used_options.append("MB")

        # pH options
        self.A_12 = self.medium.getpH()
        temp = options.get("pHo")
        self.medium.setpH(temp)
        #options["pHo"] = self.medium.getpH()
        #used_options.append("pHo")

        self.phadjust()  # Assuming phadjust is defined elsewhere

        # Na x Glucamine
        temp = options.get("Na x Glucamine")
        if temp is not None:
            self.i_72 = float(temp)
            options["Na x Glucamine"] = self.i_72
            #used_options.append("Na x Glucamine")
            self.medium.Glucamine.setConcentration(self.medium.Glucamine.getConcentration() + self.i_72)
            self.medium.Na.setConcentration(self.medium.Na.getConcentration() - self.i_72)

        # A x Gluconate
        temp = options.get("A x Gluconate")
        if temp is not None:
            self.i_73 = float(temp)
            options["A x Gluconate"] = self.i_73
            #used_options.append("A x Gluconate")
            self.medium.Gluconate.setConcentration(self.medium.Gluconate.getConcentration() + self.i_73)
            self.medium.A.setConcentration(self.medium.A.getConcentration() - self.i_73)
            if self.i_73 != 0.0:
                temp2 = options.get("clxdur")
                if temp2 is not None:
                    self.T_6 = float(temp2)
                    options["clxdur"] = self.T_6
                    #used_options.append("clxdur")

        # Replace KCl with NaCl
        temp = options.get("Replace KCl with NaCl")
        if temp is not None:
            self.i_40 = float(temp)
            options["Replace KCl with NaCl"] = self.i_40
            #used_options.append("Replace KCl with NaCl")
            self.medium.Na.setConcentration(self.medium.Na.getConcentration() + self.i_40)
            self.medium.K.setConcentration(self.medium.K.getConcentration() - self.i_40)

        # Replace NaCl with KCl
        temp = options.get("Replace NaCl with KCl")
        if temp is not None:
            self.i_33 = float(temp)
            options["Replace NaCl with KCl"] = self.i_33
            #used_options.append("Replace NaCl with KCl")
            self.medium.Na.setConcentration(self.medium.Na.getConcentration() - self.i_33)
            self.medium.K.setConcentration(self.medium.K.getConcentration() + self.i_33)

        # NaCl add/remove
        temp = options.get("NaCl add/remove")
        if temp is not None:
            self.i_45 = float(temp)
            options["NaCl add/remove"] = self.i_45
            #used_options.append("NaCl add/remove")
            self.medium.Na.setConcentration(self.medium.Na.getConcentration() + self.i_45)
            self.medium.A.setConcentration(self.medium.A.getConcentration() + self.i_45)

        # KCl add/remove
        temp = options.get("KCl add/remove")
        if temp is not None:
            self.i_34 = float(temp)
            options["KCl add/remove"] = self.i_34
            #used_options.append("KCl add/remove")
            self.medium.K.setConcentration(self.medium.K.getConcentration() + self.i_34)
            self.medium.A.setConcentration(self.medium.A.getConcentration() + self.i_34)

        # Sucrose add/remove
        temp = options.get("Sucrose add/remove")
        if temp is not None:
            self.i_46 = float(temp)
            options["Sucrose add/remove"] = self.i_46
            #used_options.append("Sucrose add/remove")
            self.medium.Sucrose.setConcentration(self.medium.Sucrose.getConcentration() + self.i_46)

        # MMg
        temp = options.get("MMg")
        if temp is not None:
            mgtold = self.medium.Mgt.getConcentration()
            self.medium.Mgt.setConcentration(float(temp))
            options["MMg"] = self.medium.Mgt.getConcentration()
            #used_options.append("MMg")
            if self.medium.Mgt.getConcentration() != 0.0:
                self.medium.A.setConcentration(
                    self.medium.A.getConcentration() + 2.0 * (self.medium.Mgt.getConcentration() - mgtold))

        # MCa
        temp = options.get("MCa")
        if temp is not None:
            catold = self.medium.Cat.getConcentration()
            self.medium.Cat.setConcentration(float(temp))
            options["MCa"] = self.medium.Cat.getConcentration()
            #used_options.append("MCa")
            if self.medium.Cat.getConcentration() != 0.0:
                self.medium.A.setConcentration(
                    self.medium.A.getConcentration() + 2.0 * (self.medium.Cat.getConcentration() - catold))

        # MEDGTA
        temp = options.get("MEDGTA")
        if temp is not None:
            self.edgto = float(temp)
            options["MEDGTA"] = self.edgto
            #used_options.append("MEDGTA")

        # Final adjustments
        self.edgto = 0.0
        self.medium.Mgf.setConcentration(self.medium.Mgt.getConcentration())
        self.medium.Caf.setConcentration(self.medium.Cat.getConcentration())

        self.chelator()
        self.oldedgta()

        self.chelated = True

        #return options

    def phadjust(self):
        # Update H concentration based on pH
        self.medium.H.setConcentration(10 ** -self.medium.getpH())
        self.pkhepes = 7.83 - 0.014 * self.temperature
        self.A_5 = 10 ** -self.pkhepes
        self.medium.Hb.setConcentration(
            self.buffer_conc * self.medium.H.getConcentration() / (self.A_5 + self.medium.H.getConcentration())
        )

    def get_medium_na_concentration(self):
        return self.medium.Na.getConcentration()

    def get_medium_k_concentration(self):
        return self.medium.K.getConcentration()

    def set_piezo_options(self, piezo_options):

        # Check if piezo stage is active
        #pz_stage = piezo_options.get("pz_stage")
        #if pz_stage is None or pz_stage != "yes":
        #    return #use

        # Set piezo parameters with values from the dictionary
        piezo_start = piezo_options.get("piezo_start")
        if piezo_start is not None:
            self.piezo.set_start_time(float(piezo_start))
            piezo_options["piezo_start"] = self.piezo.get_start_time()
            #used_options.append("piezo_start")

        pz_open_state = piezo_options.get("pz_open_state")
        if pz_open_state is not None:
            duration_s = float(pz_open_state)
            duration_h = duration_s
            self.piezo.set_duration(duration_h)
            piezo_options["pz_open_state"] = duration_s
            #used_options.append("pz_open_state")

        piezo_recovery = piezo_options.get("piezo_recovery")
        if piezo_recovery is not None:
            self.piezo.set_recovery(float(piezo_recovery))
            piezo_options["piezo_recovery"] = self.piezo.get_recovery()
            #used_options.append("piezo_recovery")

        pz_cycles_per_print = piezo_options.get("pz_cycles_per_print")
        if pz_cycles_per_print is not None:
            self.piezo.set_cycles(int(pz_cycles_per_print))
            piezo_options["pz_cycles_per_print"] = self.piezo.get_cycles()
            #used_options.append("pz_cycles_per_print")

        pz_k = piezo_options.get("pz_k")
        if pz_k is not None:
            self.piezo.set_pkg(float(pz_k))
            piezo_options["pz_k"] = self.piezo.get_pkg()
            #used_options.append("pz_k")

        pz_na = piezo_options.get("pz_na")
        if pz_na is not None:
            self.piezo.set_pnag(float(pz_na))
            piezo_options["pz_na"] = self.piezo.get_pnag()
            #used_options.append("pz_na")

        pz_ca = piezo_options.get("pz_ca")
        if pz_ca is not None:
            self.piezo.set_pcag(float(pz_ca))
            piezo_options["pz_ca"] = self.piezo.get_pcag()
            #used_options.append("pz_ca")

        pz_a = piezo_options.get("pz_a")
        if pz_a is not None:
            self.piezo.set_pag(float(pz_a))
            piezo_options["pz_a"] = self.piezo.get_pag()
            #used_options.append("pz_a")

        pmca_inhibition = piezo_options.get("pmca_inhibition")
        if pmca_inhibition is not None:
            self.piezo.set_pmca(float(pmca_inhibition))
            piezo_options["pmca_inhibition"] = self.piezo.get_pmca()
            #used_options.append("pmca_inhibition")

        pz_frequency_factor = piezo_options.get("pz_frequency_factor")
        if pz_frequency_factor is not None:
            self.piezo.set_i_f(float(pz_frequency_factor))
            piezo_options["pz_frequency_factor"] = self.piezo.get_i_f()
            #used_options.append("pz_frequency_factor")

        transit_cell_volume_fraction = piezo_options.get("transit_cell_volume_fraction")
        if transit_cell_volume_fraction is not None:
            self.piezo.set_piezo_fraction(float(transit_cell_volume_fraction))
            piezo_options["transit_cell_volume_fraction"] = self.piezo.get_piezo_fraction()
            #used_options.append("transit_cell_volume_fraction")

        pz_js_is = piezo_options.get("pz_js_is")
        if pz_js_is is not None:
            jsfactor = (100.0 - float(pz_js_is)) / 100.0
            self.piezo.set_piezo_js(jsfactor)
            piezo_options["pz_js_is"] = (1.0 - self.piezo.get_piezo_js()) * 100.0
            #used_options.append("pz_js_is")

        restore_medium = piezo_options.get("restore_medium")
        if restore_medium is not None:
            self.piezo.set_restore_medium(restore_medium == "yes")
            piezo_options["restore_medium"] = "yes" if self.piezo.get_restore_medium() else "no"
            #used_options.append("restore_medium")

        restored_hepes_na = piezo_options.get("restored_hepes_na")
        if restored_hepes_na is not None:
            self.piezo.set_restore_hepes_na(float(restored_hepes_na))
            piezo_options["restored_hepes_na"] = self.piezo.get_restore_hepes_na()
            #used_options.append("restored_hepes_na")

        restored_ph = piezo_options.get("restored_ph")
        if restored_ph is not None:
            self.piezo.set_restore_ph(float(restored_ph))
            piezo_options["restored_ph"] = self.piezo.get_restore_ph()
            #used_options.append("restored_ph")

        restored_na = piezo_options.get("restored_na")
        if restored_na is not None:
            self.piezo.set_restore_na(float(restored_na))
            piezo_options["restored_na"] = self.piezo.get_restore_na()
            #used_options.append("restored_na")

        restored_k = piezo_options.get("restored_k")
        if restored_k is not None:
            self.piezo.set_restore_k(float(restored_k))
            piezo_options["restored_k"] = self.piezo.get_restore_k()
            #used_options.append("restored_k")

        restored_mg = piezo_options.get("restored_mg")
        if restored_mg is not None:
            self.piezo.set_restore_mg(float(restored_mg))
            piezo_options["restored_mg"] = self.piezo.get_restore_mg()
            #used_options.append("restored_mg")

        restored_ca = piezo_options.get("restored_ca")
        if restored_ca is not None:
            self.piezo.set_restore_ca(float(restored_ca))
            piezo_options["restored_ca"] = self.piezo.get_restore_ca()
            #used_options.append("restored_ca")

        return piezo_options

    def get_sampling_time(self) -> float:
        return self.sampling_time

    def set_sampling_time(self, value: float) -> None:
        self.sampling_time = value

    def get_duration_experiment(self) -> float:
        return self.duration_experiment

    def set_duration_experiment(self, duration_experiment: float) -> None:
        self.duration_experiment = duration_experiment

    def get_ca_pump(self):
        return self

    def get_na_pump(self):
        return self

    # def set_publish(self, value: bool):
    #    pass

    def get_b1ca(self):
        """Return the value of b1ca."""
        return self.b1ca

    def set_b1ca(self, value):
        """Set the value of b1ca."""
        if not isinstance(value, (int, float)):
            raise ValueError("b1ca must be a number.")
        self.b1ca = float(value)

    def get_b1cak(self):
        """Return the value of b1cak."""
        return self.b1cak

    def set_b1cak(self, value):
        """Set the value of b1cak."""
        if not isinstance(value, (int, float)):
            raise ValueError("b1cak must be a number.")
        self.b1cak = float(value)

    def get_vw(self):
        return self.vw

    def set_vw(self, value):
        self.vw = value

    def get_hb_content(self):
        return self._hb_content

    def set_hb_content(self, value):
        self._hb_content = value

    def get_mgb0(self):
        return self.mgb0

    def set_mgb0(self, mgb0):
        self.mgb0 = mgb0

    def get_dpgp(self):
        return self.dpgp

    def set_dpgp(self, dpgp):
        self.dpgp = dpgp

    def set_alpha(self, alpha):
        self.alpha = float(alpha)

    def get_alpha(self):
        return self.alpha

    def set_atp(self, atp):
        self.atp = float(atp)

    def get_atp(self):
        return self.atp

    def setB1ca(self, b1ca):
        self.b1ca = float(b1ca)

    def setB1cak(self, b1cak):
        self.b1cak = float(b1cak)

    def setbenz2(self, benz2):
        self.benz2 = float(benz2)

    def get_dp(self):
        return self.dp

    def set_dp(self, value):
        self.dp = value

    def get_benz2(self) -> float:
        return self.benz2

    def set_benz2(self, value):
        self.benz2 = float(value)

    def get_cbenz2(self):
        return self.cbenz2

    def set_cbenz2(self, value):
        self.cbenz2 = float(value)

    def get_vlysis(self):
        return self.vlysis

    def set_vlysis(self, vlysis):
        self.vlysis = float(vlysis)

    def clear_results(self):
        self.result_list = []

    def get_last_result(self):
        return self.result_list[-1] if self.result_list else None

    def set_results(self, result_list):
        self.result_list = result_list

    def get_integration_interval_factor(self):
        """Getter for integration_interval_factor"""
        return self.integration_interval_factor

    def set_integration_interval_factor(self, value):
        """Setter for integration_interval_factor"""
        if not isinstance(value, (int, float)):
            raise ValueError("integration_interval_factor must be a number.")
        self.integration_interval_factor = float(value)

    def get_compute_delta_time(self):
        """Getter for compute_delta_time"""
        return self.compute_delta_time

    def set_compute_delta_time(self, value):
        """Setter for compute_delta_time"""
        if not isinstance(value, bool):
            raise ValueError("compute_delta_time must be a boolean.")
        self.compute_delta_time = value

    def get_delta_time(self):
        """Getter for delta_time"""
        return self.delta_time

    def set_delta_time(self, value):
        """Setter for delta_time"""
        if not isinstance(value, (int, float)):
            raise ValueError("delta_time must be a number (int or float).")
        self.delta_time = float(value)  # Ensures the value is stored as a float

    def get_cycles_per_print(self):
        """Getter for cycles_per_print"""
        return self.cycles_per_print

    def set_cycles_per_print(self, value):
        """Setter for cycles_per_print"""
        if not isinstance(value, int):
            raise ValueError("cycles_per_print must be an integer.")
        self.cycles_per_print = value  # Directly assign the integer value

    def safe_log_division(self, numerator, denominator):
        if numerator == 0 and denominator == 0:
            return 0
        elif denominator == 0:
            return float('inf')
        else:
            return math.log(numerator / denominator)

    def get_A_1(self):
        return self.A_1

    def set_A_1(self, value):
        self.A_1 = value

    def get_pit0(self):
        return self.pit0

    def set_pit0(self, value):
        self.pit0 = value

    def set_i_43(self, param):
        self.i_43 = param
        pass

    def get_i_43(self):
        return self.i_43
