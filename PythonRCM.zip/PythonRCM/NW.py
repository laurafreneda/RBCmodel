from abc import ABC, abstractmethod


class NWRunner(ABC):
    @abstractmethod
    def run1(self, param_double: float) :
        pass

