from Region import Region
from Napump import NaPump



class CaPumpMg2:
    def __init__(self, cell, medium,temp):
        # Initialize properties
        self.cell = Region()
        self.medium = Region()
        self.cell = cell
        self.medium = medium
        self.hik = 4.0E-7
        self.capmgk = 0.1
        self.capmgki = 7.0
        self.fcapm = 12.0
        self.h1 = 4.0
        self.capk = 2.0E-4
        self.flux_Ca = -0.03
        self.flux_H = 0.0
        self.cah = 0.0
        self.defaultFcapm = 0
        self.temperature = temp

    def compute_flux(self):

        self.set_default_fcapm(fcapm=self.fcapm)

        # Compute intermediate values
        mg_concentration = self.cell.Mgf.getConcentration()
        h_concentration = self.cell.H.getConcentration()
        caf_concentration = self.cell.Caf.getConcentration()

        npu = NaPump(temperature=self.temperature, cell=self.cell,medium=self.medium)
        npu.compute_I()
        i_17 = npu.I_17

        capmg = mg_concentration / (self.capmgk + mg_concentration) * self.capmgki / (self.capmgki + mg_concentration)
        caphik = self.hik / (self.hik + h_concentration)
        fcapglobal = -(self.get_fcapm() / i_17) * capmg * caphik

        # Compute flux_Ca
        self.flux_Ca = fcapglobal * (caf_concentration ** self.h1) / (
                    self.capk ** self.h1 + caf_concentration ** self.h1)


        # Compute flux_H based on cah
        if self.cah == 1:
            self.flux_H = -self.flux_Ca
        elif self.cah == 2:
            self.flux_H = 0.0
        elif self.cah == 0:
            self.flux_H = -2.0 * self.flux_Ca


    # Getters and Setters
    def get_fcapm(self):
        return self.fcapm

    def get_default_fcapm(self):
        return self.defaultFcapm

    def set_default_fcapm(self, fcapm):
        self.defaultFcapm = fcapm
        self.set_fcapm(fcapm)

    def set_fcapm(self, fcapm):
        self.fcapm = fcapm

    def set_capk(self, capk):
        self.capk = capk

    def get_h1(self):
        return self.h1

    def set_h1(self, h1):
        self.h1 = h1

    def get_cah(self):
        return self.cah

    def set_cah(self, cah):
        self.cah = cah

    def get_hik(self):
        return self.hik

    def set_hik(self, hik):
        self.hik = hik

    def get_capmgk(self):
        return self.capmgk

    def set_capmgk(self, capmgk):
        self.capmgk = capmgk

    def get_flux_h(self):
        return self.flux_H

    def set_flux_h(self, flux_H):
        self.flux_H = flux_H

    def get_flux_ca(self):
        return self.flux_Ca

    def set_flux_ca(self, flux_Ca):
        self.flux_Ca = flux_Ca


