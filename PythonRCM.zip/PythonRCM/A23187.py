from Region import Region

class A23187:

    def __init__(self, cell, medium, i_18: float):

        self.cell = Region()
        self.medium = Region()
        self.medium = medium
        self.cell = cell
        self.camk = 10.0
        self.mgmk = 10.0
        self.caik = 10.0
        self.mgik = 10.0
        self.flux_Mg = 0.0
        self.flux_Ca = 0.0
        self.i_18 = i_18
        self.permeability_Ca = 0.01
        self.permeability_Mg = 0.01

    def compute_flux(self):
        mgcao = self.medium.Mgf.getConcentration() / (
                self.mgmk + (self.mgmk * self.medium.Caf.getConcentration() / self.caik) +
                self.medium.Mgf.getConcentration()
        )
        camgo = self.medium.Caf.getConcentration() / (
                self.camk + (self.camk * self.medium.Mgf.getConcentration() / self.mgik) +
                self.medium.Caf.getConcentration()
        )
        mgcai = self.cell.Mgf.getConcentration() / (
                self.mgmk + (self.mgmk * self.cell.Caf.getConcentration() / self.caik) +
                self.cell.Mgf.getConcentration()
        )
        camgi = self.cell.Caf.getConcentration() / (
                self.camk + (self.camk * self.cell.Mgf.getConcentration() / self.mgik) +
                self.cell.Caf.getConcentration()
        )

        self.flux_Mg = self.permeability_Mg / self.i_18 * (
                mgcao * self.cell.H.getConcentration() ** 2 -
                mgcai * self.medium.H.getConcentration() ** 2
        )

        self.flux_Ca = self.permeability_Ca / self.i_18 * (
                camgo * self.cell.H.getConcentration() ** 2 -
                camgi * self.medium.H.getConcentration() ** 2
        )

    def get_flux_Mg(self):
        return self.flux_Mg

    def set_flux_Mg(self, value):
        self.flux_Mg = value

    def get_flux_Ca(self):
        return self.flux_Ca

    def set_flux_Ca(self, value):
        self.flux_Ca = value

    def get_permeability_Mg(self):
        return self.permeability_Mg

    def set_permeability_Mg(self, value):
        self.permeability_Mg = value

    def get_camk(self):
        return self.camk

    def set_camk(self, value):
        self.camk = value

    def get_mgmk(self):
        return self.mgmk

    def set_mgmk(self, value):
        self.mgmk = value

    def get_caik(self):
        return self.caik

    def set_caik(self, value):
        self.caik = value

    def get_mgik(self):
        return self.mgik

    def set_mgik(self, value):
        self.mgik = value

    def get_permeability_Ca(self):
        return self.permeability_Ca

    def set_permeability_Ca(self, value):
        self.permeability_Ca = value
