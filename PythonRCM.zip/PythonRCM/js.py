from dataclasses import dataclass, field
from Region import Region

class JacobsStewart:
    def __init__(self, cell: Region, medium: Region):
        self.cell = cell
        self.medium = medium
        self.permeability = 2.5e8
        self.default_permeability = 2.5e8
        self.flux_A = 0.0
        self.flux_H = 0.0

    def compute_flux(self, I_18: float) -> None:
        I_13 = -(self.permeability / I_18) * (
            self.cell.A.getConcentration() * self.cell.H.getConcentration() -
            self.medium.A.getConcentration() * self.medium.H.getConcentration()
        )
        self.flux_A = I_13
        self.flux_H = I_13

    def get_flux_A(self) -> float:
        return self.flux_A

    def get_flux_H(self) -> float:
        return self.flux_H

    def get_permeability(self) -> float:
        return self.permeability

    def get_default_permeability(self) -> float:
        return self.default_permeability

    def set_default_permeability(self, permeability: float) -> None:
        self.default_permeability = permeability
        self.set_permeability(permeability)

    def set_permeability(self, permeability: float) -> None:
        self.permeability = permeability