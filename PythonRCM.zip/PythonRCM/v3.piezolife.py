import math
import numpy as np
import pandas as pd
from typing import Dict, List, Any
from run import RBCModel
from ResultHash import ResultHash
from Napump import NaPump
from CaPumpMg2 import CaPumpMg2
from Region import Region


class PiezoLifespan:
    def __init__(self):
        # Define default options
        self.publish_order = [
            "V/V", "Vw", "Hct", "Em", "pHi", "pHo", "MCHC", "Density",
            "QNa", "QK", "QA", "QCa", "QMg", "CNa", "CK", "CA", "CH/nM",
            "CCa2+", "CMg2+", "CX", "CHb", "fHb", "COs", "MOs", "rA",
            "rH", "nHb", "MNa", "MK", "MA", "MH/nM", "MB", "MCat", "MCaf",
            "MMgt", "MMgf", "FNaP", "FACo", "FKCo", "FNaCo", "FCaP",
            "FKP", "FNa", "FKGgardos", "FKG", "FK", "FA", "FH", "FCa",
            "FW", "FNaG", "FAG", "FHG", "FCaG", "FAJS", "FHJS", "FA23Ca",
            "FA23Mg", "EA", "EH", "EK", "ENa", "FzKG", "FzNaG", "FzAG",
            "FzCaG", "fHb*CHb", "nX", "Msucr", "Mgluc-", "Mgluc+", "EN test"
        ]

        # Set up simulation parameters
        self.ds_options: Dict[str, str] = {
            "Time": "1.0",
            "Pz stage no or yes": "yes",
            "Accuracy": "6",
            "PzCaG": "70",
            "PzFrequencyFactor": "0.001",
            "Restore Medium (no/yes)": "yes"
        }
        self.rs_options: Dict[str, str] = {
            "Na/K pump Na efflux": "-3.2",
            "CK": "145.0",
            "CNa": "5.0",
            "CA": "95.0",
            "Vw": "0.85",
            "KCa Gardos channel": "0.01"
        }

        self.results: List[Dict[str, Any]] = []
        self.rbc_model: RBCModel = None
        self.worker: ModelWorker = None
        self.total_cycle_count = 0
        self.cell = Region()
        self.medium = Region()

    def setup_model(self):
        """Setup the RBC model."""
        self.rbc_model = RBCModel(self.cell, self.medium)
        self.rbc_model.set_lifespan(True)
        self.rbc_model.set_publish_order(self.publish_order)
        self.rbc_model.set_verbose(False)
        self.rs_options = self.rbc_model.setup()
        self.ds_options = self.rbc_model.setupDS()

    def run_simulation(self):
        """Start the simulation."""
        self.worker = ModelWorker(self)
        self.worker.run()

    def get_total_cycle_count(self):
        return self.total_cycle_count


class ModelWorker:
    def __init__(self, parent: PiezoLifespan):
        self.parent = parent
        self.rbc_model = self.parent.rbc_model
        self.cell = Region()
        self.medium = Region()
        self.temperature = self.rbc_model.temperature

    def run(self):
        """Run the simulation process."""

        npu = NaPump(temperature=self.temperature, cell=self.cell, medium=self.medium)
        capump = CaPumpMg2(cell=self.cell, medium=self.medium, temp=self.temperature)
        time = 0
        max_time = float(self.parent.ds_options["Time"])
        cycles_per_output = int(self.parent.ds_options.get("CyclesPerOutput", 10))
        cycle_counter = 0
        na_k = float(self.parent.ds_options["Na/K pump Na efflux"])
        pmca_k = float(self.parent.ds_options.get("PmcaK", 1e-5))
        tnap = float(self.parent.ds_options.get("Tnap", 115200))
        f_max_ca = capump.get_default_fcapm()
        f_max_na = npu.get_P_1()
        f_max_na_rev = npu.get_P_2()

        try:
            while time * 60.0 <= max_time:
                time_in_minutes = time * 60.0
                self.rbc_model.get_ca_pump().set_default_fcapm(f_max_ca * math.exp(-pmca_k * time_in_minutes))
                if time_in_minutes > tnap:
                    npu.set_P_1(f_max_na * math.exp(-na_k * (time_in_minutes - tnap)))
                    npu.set_P_2(f_max_na_rev * math.exp(-na_k * (time_in_minutes - tnap)))
                self.rbc_model.runall()  # Pass None for the model_output, if not used

                # Collect and print current state
                current_state = {
                    'time': time * 60.0,
                    'Em': self.rbc_model.Em,
                    'V/V': self.rbc_model.vv,
                    'cell_K': self.cell.K.getConcentration(),
                    'cell_A': self.cell.A.getConcentration(),
                    'medium_Na': self.medium.Na.getConcentration(),
                    'medium_K': self.medium.K.getConcentration(),
                    'medium_A': self.medium.A.getConcentration()
                }
                print(f"Appending result: {current_state}")  # Debugging line
                self.parent.results.append(current_state)

                # Process results
                self.process_results(self.parent.results)

                time += self.rbc_model.get_delta_time()
                cycle_counter += 1
                if cycle_counter == cycles_per_output:
                    self.rbc_model.publish()
                    cycle_counter = 0

            self.rbc_model.publish()
            self.parent.total_cycle_count = self.rbc_model.get_total_cycle_count()
        except Exception as e:
            print(f"An error occurred: {e}")

    def process_results(self, results: List[Dict[str, Any]]):
        if not results:
            print("No results to process.")
        else:
            print("Processing results...")
            for result in results:
                print(f"Time: {result['time']:.2f} s, Em: {result['Em']:.2f} mV, "
                      f"Cell V/V: {result['V/V']:.2f}, Cell K: {result['cell_K']:.2f} mM, "
                      f"Cell A: {result['cell_A']:.2f} mM, Medium Na: {result['medium_Na']:.2f} mM, "
                      f"Medium K: {result['medium_K']:.2f} mM, Medium A: {result['medium_A']:.2f} mM ")

        data_tuples = [
            (
                state.get('time', np.nan),
                state.get('Em', np.nan),
                state.get('V/V', np.nan),
                state.get('cell_K', np.nan),
                state.get('cell_A', np.nan),
                state.get('medium_Na', np.nan),
                state.get('medium_K', np.nan),
                state.get('medium_A', np.nan)
            )
            for state in results
        ]

        results_array = np.array(data_tuples, dtype=[
            ('time', float), ('Em', float), ('V/V', float), ('cell_K', float),
            ('cell_A', float), ('medium_Na', float), ('medium_K', float),
            ('medium_A', float)
        ])

        df = pd.DataFrame(results_array)
        df.to_csv('results.csv', index=False)
        print("Results processing completed.")
        return results_array

if __name__ == "__main__":
    p = PiezoLifespan()
    p.setup_model()
    p.run_simulation()
    p.get_total_cycle_count()
