from dataclasses import dataclass

@dataclass
class MileStone:
    time: float = 0.0  # Default value for time
    name: str = ''  # Default value for name

    def get_time(self) -> float:
        """Returns the time of the milestone."""
        return self.time

    def get_name(self) -> str:
        """Returns the name of the milestone."""
        return self.name

    def check(self, current_time: float) -> bool:
        """Checks if the given time is greater than or equal to the milestone's time."""
        return current_time >= self.time

    def to_string(self) -> str:
        """Converts the milestone to a string representation."""
        return f'{self.name}: {self.time * 60.0}'

    def set_time(self, new_time: float) -> None:
        """Sets the time of the milestone."""
        self.time = new_time

