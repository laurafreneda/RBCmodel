from Region import Region


class Cotransport:

    def __init__(self, cell, medium):
        # Initialize properties with default values

        self.cell = Region()
        self.medium = Region()
        self.permeability = 1.0E-9  # Default permeability value
        self.flux_A = 0.0  # Default flux_A value
        self.flux_Na = 0.0  # Default flux_Na value
        self.flux_K = 0.0  # Default flux_K value
        self.cell = cell  # Region object for cell
        self.medium = medium  # Region object for medium
        self.zero_factor = 0.0  # Default zero_factor value

    def compute_zero_factor(self):
        # Get concentrations from cell and medium
        cellNa = self.cell.Na.getConcentration()

        cellK = self.cell.K.getConcentration()

        cellA = self.cell.A.getConcentration()

        mediumNa = self.medium.Na.getConcentration()

        mediumK = self.medium.K.getConcentration()

        mediumA = self.medium.A.getConcentration()

        # Compute zero factor

        if (cellNa * cellK * cellA ** 2) == 0 or (mediumNa * mediumK * mediumA ** 2) == 0:
            self.zero_factor = 0.0

        else:
            self.zero_factor = (
                    (cellNa * cellK * cellA ** 2) /
                    (mediumNa * mediumK * mediumA ** 2)
            )

    def compute_flux(self, i_18):
        # Get concentrations from cell and medium
        cellNa = self.cell.Na.getConcentration()
        cellK = self.cell.K.getConcentration()
        cellA = self.cell.A.getConcentration()
        mediumNa = self.medium.Na.getConcentration()
        mediumK = self.medium.K.getConcentration()
        mediumA = self.medium.A.getConcentration()


        # Compute I_12 and update flux values
        i_12 = -(self.permeability / i_18) * (
                cellA ** 2 * cellNa * cellK -
                self.zero_factor * (mediumA ** 2) * mediumNa * mediumK
        )

        self.flux_A = 2.0 * i_12
        self.flux_Na = i_12
        self.flux_K = i_12

    # Getters
    def get_flux_A(self):
        return self.flux_A

    def get_flux_Na(self):
        return self.flux_Na

    def get_flux_K(self):
        return self.flux_K

    def get_permeability(self):
        return self.permeability

    # Setter
    def set_permeability(self, permeability):
        self.permeability = permeability
