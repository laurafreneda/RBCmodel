from Region import Region
import math
from Goldman import Goldman


class PassiveCa:
    def __init__(self, cell, medium):
        self.Em = None
        self.cell = Region()
        self.medium = Region()
        self.cell = cell
        self.medium = medium
        self.flux = 0.03
        self.calk = 0.8
        self.calik = 2.0e-4
        self.fcalm = 0.05
        self.i_18 = None

    import math

    def compute_flux(self, i_18: float, em):
        self.i_18 = i_18
        self.Em = em
        calreg = (self.calik / (self.calik + self.cell.Caf.getConcentration())) * \
                 (self.medium.Caf.getConcentration() / (self.calk + self.medium.Caf.getConcentration()))

        goldman = Goldman(self.cell, self.medium)
        goldman_factor = goldman.getGoldmanFactor()

        # Check for division by zero in the denominator
        denominator = 1.0 - math.exp(2.0 * goldman_factor)



        if abs(denominator) < 1e-10 or abs(self.i_18) < 1e-10:  # Check for both potential divisions by zero
            self.flux = 0.0

        else:
            self.flux = -((self.fcalm / self.i_18) * calreg *
                          2.0 * goldman_factor *
                          (self.medium.Caf.getConcentration() - self.cell.Caf.getConcentration() *
                           math.exp(2.0 * goldman_factor)) /
                          denominator)

    def get_fcalm(self) -> float:
        return self.fcalm

    def set_fcalm(self, fcalm: float) -> None:
        self.fcalm = fcalm

    def get_flux(self) -> float:
        return self.flux

    def set_flux(self, flux: float) -> None:
        self.flux = flux
