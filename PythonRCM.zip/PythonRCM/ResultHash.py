from typing import Dict, List, Any


class ResultHash:
    def __init__(self):
        self.items = {}  # Dictionary to store lists of values for each key
        self.times = []  # List to store time values

    def set_item(self, time: float, key: str, val: Any):
        if key not in self.items:
            self.items[key] = []
        self.items[key].append(val)

        # If adding a new item, ensure the time is recorded once per unique time
        if len(self.times) < len(self.items[key]):
            self.times.append(time)

    def get_item(self, key: str) -> List[Any]:
        return self.items.get(key, [])

    def get_times(self) -> List[float]:
        return self.times
