def runall(self):
    self.cycle_count = 0
    self.n_its = 0

    milestones = self.generate_milestones()

    if not self.validate_milestones(milestones):
        print("Milestones validation failed. Exiting simulation.")
        return

    current_milestone_index = 0
    current_milestone_operation = None

    while self.sampling_time * 60 <= self.duration_experiment:
        print(f"Sampling time: {self.sampling_time}, duration {self.duration_experiment}")
        if current_milestone_operation:
            self.handle_milestone(current_milestone_operation)
            if current_milestone_operation == "END":
                break

        # Determine the next milestone operation
        if current_milestone_index < len(milestones):
            next_milestone = milestones[current_milestone_index]
            if self.integration_interval(next_milestone):
                current_milestone_operation = next_milestone.get_name()
                current_milestone_index += 1
                if self.check_termination_conditions():
                    break

                # self.handle_gluconate_adjustment()

                # Record results if conditions are met
                if self.should_record_results():
                    self.record_results()
            else:
                current_milestone_operation = None
        else:
            current_milestone_operation = None

        # Compute fluxes and update environment
        self.compute_fluxes()
        self.update_environment()
        self.total_cycle_count += 1

    self.finalize_results()

    # Exit if the operation is cancelled

    # Finalize and save results after simulation


def generate_milestones(self) -> List[MileStone]:
    milestones = []

    if self.piezo:
        milestones.extend(self.generate_piezo_milestones())

    milestones.append(MileStone(self.duration_experiment, "END"))
    return sorted(milestones, key=lambda ms: ms.time)


def generate_piezo_milestones(self) -> List[MileStone]:
    milestones = []
    if self.piezo.get_start_time() > 0.0:
        for j in range(3):
            output_time = (0.5 + j * 0.5) / 60.0 + self.sampling_time
            milestones.append(MileStone(output_time, "PUBLISH"))

    p_start = self.piezo.get_start_time() + self.sampling_time
    p_stop = p_start + self.piezo.get_duration()
    p_end = min(p_stop + self.piezo.get_recovery(), self.duration_experiment / 60.0 - 1e-6)

    milestones.extend([
        MileStone(p_start, "PIEZO START"),
        MileStone(p_stop, "PIEZO STOP"),
        MileStone(p_end, "PIEZO END")
    ])

    print(f'PIEZO START: {p_start}, PIEZO STOP: {p_stop}, PIEZO END: {p_end}')

    return milestones


def validate_milestones(self, milestones: List[MileStone]) -> bool:
    return all(milestones[i].time > milestones[i - 1].time for i in range(1, len(milestones)))


def handle_milestone(self, operation: str):
    if operation == "PIEZO START":
        self.start_piezo()
    elif operation == "PIEZO STOP":
        self.stop_piezo()
    elif operation == "PIEZO END":
        self.end_piezo()
