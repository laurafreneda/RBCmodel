from Region import Region
import math


class PiezoGoldman:
    def __init__(self, cell, medium):
        self.cell = cell
        self.medium = medium
        self.permeability_Na = 0.0
        self.permeability_A = 50.0
        self.permeability_H = 0.0
        self.permeability_K = 0.0
        self.flux_Na = 0.0
        self.flux_A = 0.0
        self.flux_H = 0.0
        self.flux_K = 0.0
        self.Goldman_factor = 0.0
        self.rtoverf = 0.0  # Initialize rtoverf
        self.foverrt = 0.0  # Initialize foverrt
        self.Em = 0.0
        self.z = 1  # Default value for z, adjust as needed
        self.i_18 = 0.0
        self.temperature = 37.0

    def compute_flux(self, i_18):
        self.i_18 = i_18

        # Compute fluxes for different species
        self.flux_Na = self.fullgflux(self.cell.Na, self.medium.Na, self.permeability_Na, self.i_18)
        self.flux_A = self.fullgflux(self.cell.A, self.medium.A, self.permeability_A, self.i_18)
        self.flux_H = self.fullgflux(self.cell.H, self.medium.H, self.permeability_H, self.i_18)
        self.flux_K = self.fullgflux(self.cell.K, self.medium.K, self.permeability_K, self.i_18)



    def gfactors(self, Em, temperature):
        self.Em = Em
        # Validate temperature
        if temperature < -273.15:
            raise ValueError('Temperature must be above absolute zero.')

        self.rtoverf = 0.086156 * (273.0 + temperature)
        self.foverrt = 1.0 / self.rtoverf
        self.Goldman_factor = self.Em * self.foverrt

    def gflux(self, cell_species, medium_species):
        z = cell_species.getZ()
        G = self.get_Goldman_factor()
        C_medium = medium_species.getConcentration()
        C_cell = cell_species.getConcentration()

        # Calculate the denominator
        denominator = 1.0 - math.exp(z * G)

        # Check if the denominator is zero
        if denominator == 0.0:
            return 0.0

        # Calculate the flux
        flux = -z * G * (C_medium - C_cell * math.exp(z * G)) / denominator

        return flux

    def fullgflux(self, cell, medium, permeability, i_18):
        if i_18 == 0:
            raise ValueError('I_18 cannot be zero.')
        return (permeability / i_18) * self.gflux(cell, medium)

    # Getters and Setters
    def get_Goldman_factor(self):
        return self.Goldman_factor

    def set_flux_A(self, flux_A):
        self.flux_A = flux_A

    def get_flux_A(self):
        return self.flux_A

    def set_flux_Na(self, flux_Na):
        self.flux_Na = flux_Na

    def get_flux_Na(self):
        return self.flux_Na

    def set_flux_K(self, flux_K):
        self.flux_K = flux_K

    def get_flux_K(self):
        return self.flux_K

    def set_flux_H(self, flux_H):
        self.flux_H = flux_H

    def get_flux_H(self):
        return self.flux_H

    def set_permeability_K(self, permeability_K):
        self.permeability_K = permeability_K

    def get_permeability_K(self):
        return self.permeability_K

    def set_permeability_Na(self, permeability_Na):
        self.permeability_Na = permeability_Na

    def get_permeability_Na(self):
        return self.permeability_Na

    def set_permeability_A(self, permeability_A):
        self.permeability_A = permeability_A

    def get_permeability_A(self):
        return self.permeability_A

    def set_permeability_H(self, permeability_H):
        self.permeability_H = permeability_H

    def get_permeability_H(self):
        return self.permeability_H

    def get_rtoverf(self):
        return self.rtoverf

    def get_foverrt(self):
        return self.foverrt
