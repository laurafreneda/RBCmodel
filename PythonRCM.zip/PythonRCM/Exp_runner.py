from run import RBCModel  # Import RBCModel from your module
from Region import Region


def initialize_piezo_options():
    # Initialize piezo options with default values
    piezo_options = {
        "piezo_start": 0.0,  # Default start time in minutes
        "pz_open_state": 0.4/3600.0,  # Default open state duration in seconds (1 hour)
        "piezo_recovery": 0.016666666666666666/60,  # Default recovery time in minutes (5 minutes)
        "pz_cycles_per_print": 111,  # Default number of cycles per print
        "pz_k": 0.0,  # Default value for pz_k
        "pz_na": 0.0,  # Default value for pz_na
        "pz_ca": 70.0,  # Default value for pz_ca
        "pz_a": 50.0,  # Default value for pz_a
        "pmca_inhibition": 0.0,  # Default PMCA inhibition value
        "pz_frequency_factor": 1.0E-5,  # Default frequency factor
        "transit_cell_volume_fraction": 0.9,  # Default cell volume fraction
        "pz_js_is": 1.0,  # Default JS factor percentage
        "restore_medium": "yes",  # Default value for restore medium
        "restored_hepes_na": 10,  # Default restored HEPES-Na concentration
        "restored_ph": 7.4,  # Default restored pH value
        "restored_na": 145.0,  # Default restored Na concentration
        "restored_k": 5.0,  # Default restored K concentration
        "restored_mg": 0.2,  # Default restored Mg concentration
        "restored_ca": 1.0  # Default restored Ca concentration
    }
    return piezo_options


def initialize_options():
    options = {
        "CVF": 0.1,  # Example value for Cell Volume Fraction
        "MB": 10.0,  # Example value for Buffer Concentration (MB)
        "pHo": 7.4,  # Example value for pH
        "Na x Glucamine": 0.0,  # Example value for Na x Glucamine
        "A x Gluconate": 0.0,  # Example value for A x Gluconate
        "clxdur": 60.0,  # Example duration in minutes for clxdur
        "Replace KCl with NaCl": None,  # Example value for replacing KCl with NaCl
        "Replace NaCl with KCl": None,  # Example value for replacing NaCl with KCl
        "NaCl add/remove": None,  # Example value for adding/removing NaCl
        "KCl add/remove": None,  # Example value for adding/removing KCl
        "Sucrose add/remove": None,  # Example value for adding/removing Sucrose
        "MMg": 0.2,  # Example value for Magnesium concentration (MMg)
        "MCa": 1.0,  # Example value for Calcium concentration (MCa)
        "MEDGTA": 0.0,  # Example value for EDGTA concentration
        "Pw": 2.0,
        "PK": 0.0017,
        "PNa": 0.0015,
        "PA": 1.2,
        "PH": 0.0000000002,
        "PCa": 0.5,
        "PA23CaMg": 0.01,
        "PMCA FCaPmax": 12,
        "cato-medium": 1.2,
        "add-ca-buffer": 0.03,
        "kd-of-ca-buffer": 0.015,
        "alpha": 0.35,
        "benz2loaded": 0.0,
        "k1/2": 0.0025,
        "hills": 3.5,
        "pump-electro": 1,
        "h+ki": 3.5E-7,
        "Mg2+K1/2": 0.05,
        "PCaG": 0.07,
        "PKGardosMax": 30,
        "KCa Gardos channel": 0.01
    }

    return options

    # Now you can pass this options dictionary to the set_cell_fraction_options method:


def main():
    cell = Region()
    medium = Region()
    rbc = RBCModel(cell, medium)

    # Initialize RBCModel instance

    print("Initializing RBCModel...")  # Debug print

    # Initialize empty dictionaries
    piezo_options = initialize_piezo_options()
    options = initialize_options()

    rbc.setup(options)

    # Configure DS options (assuming default or pre-configured options)
    rbc.setupDS(piezo_options, options)
    #print(rbc.medium.K.getConcentration(), rbc.cell.K.getConcentration())
    rbc.runall()

    print("Finalizing and saving results...")  # Debug print


if __name__ == "__main__":
    main()
