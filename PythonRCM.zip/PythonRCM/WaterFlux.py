from Region import Region


class WaterFlux:
    def __init__(self, cell, medium):
        self.edgto = None
        # self.permeability = None
        self.i_18 = None
        self.cbenz2 = None
        self.fHb = None
        self.buffer_conc = None
        self.cell = Region()
        self.medium = Region()
        self.cell = cell
        self.medium = medium
        self.setPermeability(2.0)
        self.flux = 0.0  # Initialize flux

    def compute_flux(self, fHb, cbenz2, edgto, i_18, buffer_conc):
        # Debug: Print the input arguments
        self.fHb = fHb
        print(f'fHb = {fHb}')
        self.cbenz2 = cbenz2
        print(f'cbenz2 = {cbenz2}')
        self.i_18 = i_18
        print(f'i_18 = {i_18}')
        self.edgto = edgto
        print(f'edgto = {edgto}')
        self.buffer_conc = buffer_conc
        print(f'buffer_conc = {buffer_conc}')

        # Update the Os concentration for the cell
        na_concentration_cell = self.cell.Na.getConcentration()
        k_concentration_cell = self.cell.K.getConcentration()
        a_concentration_cell = self.cell.A.getConcentration()
        hb_concentration_cell = fHb * self.cell.Hb.getConcentration()
        x_concentration_cell = self.cell.X.getConcentration()
        mgf_concentration_cell = self.cell.Mgf.getConcentration()
        caf_concentration_cell = self.cell.Caf.getConcentration()

        os_cell = (na_concentration_cell +
                   k_concentration_cell +
                   a_concentration_cell +
                   hb_concentration_cell +
                   x_concentration_cell +
                   mgf_concentration_cell +
                   caf_concentration_cell +
                   cbenz2)

        self.cell.Os.setConcentration(os_cell)
        #print(f'os_cell = {os_cell}')

        # Update the Os concentration for the medium
        na_concentration_medium = self.medium.Na.getConcentration()
        k_concentration_medium = self.medium.K.getConcentration()
        a_concentration_medium = self.medium.A.getConcentration()
        gluconate_concentration_medium = self.medium.Gluconate.getConcentration()
        glucamine_concentration_medium = self.medium.Glucamine.getConcentration()
        sucrose_concentration_medium = self.medium.Sucrose.getConcentration()
        mgf_concentration_medium = self.medium.Mgf.getConcentration()
        caf_concentration_medium = self.medium.Caf.getConcentration()

        os_medium = (na_concentration_medium +
                     k_concentration_medium +
                     a_concentration_medium +
                     buffer_conc +
                     gluconate_concentration_medium +
                     glucamine_concentration_medium +
                     sucrose_concentration_medium +
                     mgf_concentration_medium +
                     caf_concentration_medium +
                     edgto)

        #print(f'os_medium = {os_medium}')

        self.medium.Os.setConcentration(os_medium)

        # Debug: Confirm that the concentrations have been set
        # Compute flux
        D_7 = self.cell.Os.getConcentration() - self.medium.Os.getConcentration()

        calculated_flux = self.getPermeability() / self.i_18 * D_7
        print(f'Calculated flux: {calculated_flux}')

        self.setFlux(calculated_flux)

    def getFlux(self):
        # Get the current flux value
        return self.flux

    def setFlux(self, flux):
        # Set the flux value
        self.flux = flux

    def getPermeability(self):
        # Get the current permeability value
        return self.permeability

    def setPermeability(self, permeability):
        # Set the permeability value
        self.permeability = permeability
