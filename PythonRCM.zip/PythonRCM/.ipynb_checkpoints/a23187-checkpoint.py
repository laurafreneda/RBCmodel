# modelcomponents/a23187.py

from dataclasses import dataclass

@dataclass
class Region:
    Mgf: 'Concentration'
    Caf: 'Concentration'
    H: 'Concentration'

@dataclass
class Concentration:
    value: float

    def get_concentration(self) -> float:
        return self.value

class A23187:
    def __init__(self, cell: Region, medium: Region):
        self.cell = cell
        self.medium = medium
        self.camk = 10.0
        self.mgmk = 10.0
        self.caik = 10.0
        self.mgik = 10.0
        self.flux_Mg = 0.0
        self.flux_Ca = 0.0
        self.permeability_Mg = 0.01
        self.permeability_Ca = 0.01

    def compute_flux(self, I_18: float):
        mgcao = self.medium.Mgf.get_concentration() / (self.mgmk + self.mgmk * self.medium.Caf.get_concentration() / self.caik + self.medium.Mgf.get_concentration())
        camgo = self.medium.Caf.get_concentration() / (self.camk + self.camk * self.medium.Mgf.get_concentration() / self.mgik + self.medium.Caf.get_concentration())
        mgcai = self.cell.Mgf.get_concentration() / (self.mgmk + self.mgmk * self.cell.Caf.get_concentration() / self.caik + self.cell.Mgf.get_concentration())
        camgi = self.cell.Caf.get_concentration() / (self.camk + self.camk * self.cell.Mgf.get_concentration() / self.mgik + self.cell.Caf.get_concentration())
        
        self.flux_Mg = self.permeability_Mg / I_18 * (mgcao * self.cell.H.get_concentration()**2 - mgcai * self.medium.H.get_concentration()**2)
        self.flux_Ca = self.permeability_Ca / I_18 * (camgo * self.cell.H.get_concentration()**2 - camgi * self.medium.H.get_concentration()**2)

    def get_flux_Mg(self) -> float:
        return self.flux_Mg

    def set_flux_Mg(self, flux_Mg: float):
        self.flux_Mg = flux_Mg

    def get_flux_Ca(self) -> float:
        return self.flux_Ca

    def set_flux_Ca(self, flux_Ca: float):
        self.flux_Ca = flux_Ca

    def get_permeability_Mg(self) -> float:
        return self.permeability_Mg

    def set_permeability_Mg(self, permeability_Mg: float):
        self.permeability_Mg = permeability_Mg

    def get_camk(self) -> float:
        return self.camk

    def set_camk(self, camk: float):
        self.camk = camk

    def get_mgmk(self) -> float:
        return self.mgmk

    def set_mgmk(self, mgmk: float):
        self.mgmk = mgmk

    def get_caik(self) -> float:
        return self.caik

    def set_caik(self, caik: float):
        self.caik = caik

    def get_mgik(self) -> float:
        return self.mgik

    def set_mgik(self, mgik: float):
        self.mgik = mgik

    def get_permeability_Ca(self) -> float:
        return self.permeability_Ca

    def set_permeability_Ca(self, permeability_Ca: float):
        self.permeability_Ca = permeability_Ca

