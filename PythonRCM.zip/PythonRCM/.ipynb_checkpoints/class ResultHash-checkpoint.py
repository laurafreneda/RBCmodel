from dataclasses import dataclass, field
from typing import Any

@dataclass
class ResultHash:
    Time: float = 0.0
    items: dict = field(default_factory=dict)

    def setItem(self, key: str, val: Any):
        # Method to set an item in the items dictionary
        self.items[key] = val

    def getItem(self, key: str) -> Any:
        # Method to get an item from the items dictionary
        return self.items.get(key, None)

    def getTime(self) -> float:
        # Method to get the Time value
        return self.Time
