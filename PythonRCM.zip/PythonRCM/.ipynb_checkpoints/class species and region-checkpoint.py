from dataclasses import dataclass, field
from typing import Union

@dataclass
class Species:
    concentration: float = 0.0
    temperature: float = 0.0

    def setConcentration(self, concentration: float):
        self.concentration = concentration

    def getConcentration(self) -> float:
        return self.concentration

    def setTemperature(self, temperature: float):
        self.temperature = temperature

@dataclass
class Region:
    Na: Species = field(default_factory=Species)
    K: Species = field(default_factory=Species)
    A: Species = field(default_factory=Species)
    H: Species = field(default_factory=Species)
    Hb: Species = field(default_factory=Species)
    X: Species = field(default_factory=Species)
    Os: Species = field(default_factory=Species)
    Gluconate: Species = field(default_factory=Species)
    Glucamine: Species = field(default_factory=Species)
    Sucrose: Species = field(default_factory=Species)
    Caf: Species = field(default_factory=Species)
    Mgf: Species = field(default_factory=Species)
    Cat: Species = field(default_factory=Species)
    Mgt: Species = field(default_factory=Species)
    XHbm: Species = field(default_factory=Species)
    COs: Species = field(default_factory=Species)
    Hbpm: Species = field(default_factory=Species)
    pH: float = 0.0
    temperature: float = 0.0

    def getpH(self) -> float:
        # Get the pH value
        return self.pH

    def setpH(self, pH: float):
        # Set the pH value
        self.pH = pH

    def setTemperature(self, temperature: float):
        # Set temperature for all Species objects
        self.temperature = temperature
        # Update each species' temperature if needed
        for species in vars(self).values():
            if isinstance(species, Species):
                species.setTemperature(temperature)

    def updateIonConcentration(self, ionName: str, concentration: float):
        # Update ion concentration in Region
        if hasattr(self, ionName):
            ion = getattr(self, ionName)
            if isinstance(ion, Species):
                ion.setConcentration(concentration)
            else:
                raise ValueError(f"{ionName} is not a valid Species.")
        else:
            raise ValueError(f"Ion name {ionName} not recognized.")
