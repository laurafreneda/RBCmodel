from abc import ABC

from Region import Region
import math
from NW import NWRunner
from Goldman import Goldman
from PiezoGoldman import PiezoGoldman
from PassiveCa import PassiveCa
from PiezoPassiveCa import PiezoPassiveCa
from A23187 import A23187
from WaterFlux import WaterFlux
from CaPumpMg2 import CaPumpMg2
from Cotranssport import Cotransport
from js import JacobsStewart
from Napump import NaPump

#from run import RBCModel
from abc import ABC
from Region import Region
import math
from NW import NWRunner


class EqSolver:
    def __init__(self, atp, dpgp, vv, vw, mgb0, cell, medium, buffer_conc, A_5, A_8, lig_hb, delta_H, dedgh):
        # Initializing attributes with values from parameters
        self.it_counter = 0
        self.atp = atp
        self.dpgp = dpgp
        self.vv = vv
        self.vw = vw
        self.mgb0 = mgb0
        self.cell = cell
        self.medium = medium
        self.buffer_conc = buffer_conc
        self.A_5 = A_5
        self.A_8 = A_8
        self.lig_hb = lig_hb
        self.delta_H = delta_H
        self.dedgh = dedgh
        self.mgb0 = 0.0

    def newton_raphson(self, runner, initial, step, stop, max_its, initial_its, verbose=False):
        X_3 = initial
        no_its = initial_its
        finished = False
        #Y_3 = 0.0
        while not finished:
            X_1 = X_3 - step
            Y_1 = runner.run1(X_1)

            X_2 = X_3 + step
            Y_2 = runner.run1(X_2)

            S = (Y_2 - Y_1) / (X_2 - X_1)

            if S == 0 or Y_1 == 0:
                X_3 = X_1
            else:
                X_3 = X_1 - Y_1 / S

            Y_3 = runner.run1(X_3)

            no_its += 1

            if no_its > max_its:
                finished = True
            if abs(Y_3) < stop:
                finished = True

            self.it_counter += 1

        return X_3


class Eqca(NWRunner, ABC):
    def __init__(self, alpha, vv, b1ca, b1cak, benz2, benz2k, Cat_Amount, local_x6):
        self.alpha = alpha
        self.vv = vv
        self.b1ca = b1ca
        self.b1cak = b1cak
        self.benz2 = benz2
        self.benz2k = benz2k
        self.Cat_Amount = Cat_Amount
        self.local_x6 = local_x6

    def run1(self, local_x6):
        if self.b1cak + self.local_x6 == 0 or self.benz2k + self.local_x6 == 0:
            return 0.0

        if self.alpha == 0:

            cabb = (self.b1ca / self.vv * self.local_x6 / (self.b1cak + self.local_x6) +
                    self.benz2 / self.vv * self.local_x6 / (self.benz2k + self.local_x6))
        else:
            cabb = (local_x6 * math.pow(self.alpha, -1.0) +
                    self.b1ca / self.vv * self.local_x6 / (self.b1cak + self.local_x6) +
                    self.benz2 / self.vv * self.local_x6 / (self.benz2k + self.local_x6))

        y = self.Cat_Amount - cabb

        return y


class Eqmg(NWRunner, ABC):
    def __init__(self, buffer_conc, delta_H, lig_hb, A_8, dedgh, atp, mgb0, vw, vv, Mgt_Amount, dpgp, local_mgf):
        self.atp = atp
        self.buffer_conc = buffer_conc
        self.delta_H = delta_H
        self.lig_hb = lig_hb
        self.A_8 = A_8
        self.dedgh = dedgh
        self.mgb0 = mgb0
        self.vw = vw
        self.vv = vv
        self.hb_content = 34.0
        self.Mgt_Amount = Mgt_Amount
        self.dpgp = dpgp
        self.local_mgf = local_mgf

    def run1(self, local_mgf2):
        local_mgf2 = self.local_mgf

        if self.atp == 0 or local_mgf2 == 0 or self.vv == 0:

            mgb = self.mgb0

        elif self.dpgp == 0:

            mgb = self.mgb0 + (self.atp * local_mgf2) / (self.vv * (0.08 + local_mgf2))
        else:

            mgb = (self.mgb0 +
                   (self.atp * local_mgf2) / (self.vv * (0.08 + local_mgf2)) +
                   (self.dpgp * local_mgf2) / (self.vv * (3.6 + local_mgf2)))

        # Exclusive conditions for y calculation
        if local_mgf2 == 0 or self.vw == 0:
            y = self.Mgt_Amount - mgb
        elif self.hb_content == 0:
            y = self.Mgt_Amount - local_mgf2
        else:
            y = self.Mgt_Amount - local_mgf2 * self.vw / (self.vw + self.hb_content / 136.0) - mgb

        return y


class ComputeAllFluxes(NWRunner, ABC):
    def __init__(self, i_18, temperature, medium, cell, Em):
        self.CaFlux = None
        self.total_flux = 0.0
        self.total_flux_Ca = 0.0
        self.i_18 = i_18
        self.temperature = temperature
        self.Em = Em
        self.medium = Region()
        self.cell = Region()
        self.medium = medium
        self.cell = cell
        self.gold = Goldman(cell=self.cell, medium=self.medium)
        self.a23 = A23187(cell=self.cell, medium=self.medium, i_18=self.i_18)
        self.piezo_pass_ca = PiezoPassiveCa(cell=self.cell, medium=self.medium)
        #wtflux = WaterFlux(cell=self.cell, medium=self.medium)
        self.p_gold = PiezoGoldman(cell=self.cell, medium=self.medium)
        self.pass_ca = PassiveCa(cell=self.cell, medium=self.medium)
        self.cpu = CaPumpMg2(cell=self.cell, medium=self.medium, temp=self.temperature)
        self.npu = NaPump(temperature=self.temperature, cell=self.cell, medium=self.medium)

    def run1(self, Em):
        self.gold.compute_flux(self.temperature, self.i_18, self.Em)

        self.p_gold.compute_flux(self.i_18)

        self.a23.compute_flux()

        self.piezo_pass_ca.compute_flux(self.i_18)

        self.pass_ca.compute_flux(self.i_18, self.Em)

        self.cpu.compute_flux()

        # Assuming these methods exist in the current context (like within an RBC model)
        self.total_ca_flux()
        self.CaFlux = self.total_flux_Ca
        self.totalflux()
        var = self.total_flux

        # Return the total flux after calculations
        return var

    def total_ca_flux(self):
        a23 = A23187(cell=self.cell, medium=self.medium, i_18=self.i_18)
        piezo_pass_ca = PiezoPassiveCa(cell=self.cell, medium=self.medium)

        pass_ca = PassiveCa(cell=self.cell, medium=self.medium)
        cpu = CaPumpMg2(cell=self.cell, medium=self.medium, temp=self.temperature)

        self.total_flux_Ca = (
                a23.get_flux_Ca() + pass_ca.get_flux() + piezo_pass_ca.get_flux()
                + cpu.get_flux_ca())

    def totalflux(self):
        gold_flux = (self.gold.getFlux_H() +
                     self.gold.getFlux_Na() +
                     self.gold.getFlux_K() -
                     self.gold.getFlux_A())

        p_gold_flux = (self.p_gold.get_flux_H() +
                       self.p_gold.get_flux_Na() +
                       self.p_gold.get_flux_K() -
                       self.p_gold.get_flux_A())

        self.total_flux = (self.npu.get_total_flux() +
                           gold_flux +
                           p_gold_flux +
                           self.cpu.get_cah() * self.cpu.get_flux_ca() +
                           2.0 * self.pass_ca.get_flux() +
                           2.0 * self.piezo_pass_ca.get_flux())


class Ligs_eqs:
    def __init__(self, medium, buffer_conc, A_5, lig_hb, delta_H):
        self.edghk1 = 0.0
        self.edghk2 = 0.0
        self.edgcak = 0.0
        self.edgmgk = 0.0
        self.medium = Region()
        self.medium = medium  # This should be an object with Caf and Mgf attributes
        self.buffer_conc = buffer_conc
        self.A_5 = A_5
        self.edgto = 0.0
        self.lig_hb = lig_hb
        self.A_8 = 0.0
        self.delta_H = delta_H
        self.dedgh = 0.0
        self.ff = 0.0
        self.it_counter = 0
        self.equation_map = {
            "ligeq1": self.ligeq1_run,
            "ligeq2": self.ligeq2_run,
            "ligeq3": self.ligeq3_run
        }

    def run_equation(self, equation_name, *args):
        if equation_name in self.equation_map:
            return self.equation_map[equation_name](*args)
        else:
            raise ValueError(f"Unknown equation name: {equation_name}")

    def newton_raphson2(self, func, initial, step, stop, max_its, initial_its, verbose=False):

        X_3 = initial
        no_its = initial_its
        finished = False

        while not finished:

            X_1 = X_3 - step

            Y_1 = func(X_1)

            X_2 = X_3 + step
            Y_2 = func(X_2)
            if Y_2 - Y_1 == 0 or X_2 - X_1:
                S = 0
            else:
                S = (Y_2 - Y_1) / (X_2 - X_1)
            if S == 0 or Y_1 == 0:
                X_3 = X_1
            else:
                X_3 = X_1 - Y_1 / S

            # Check if the function is ligeq3_run or ligeq1_run
            if self.run_equation("ligeq1", X_3) or self.run_equation("ligeq3", X_3):
                Y_3 = Y_2
            else:
                Y_3 = func(X_3)

            no_its += 1
            if no_its > max_its or abs(Y_3) < stop:
                finished = True

            self.it_counter += 1

        return X_3

    def ligeq1_run(self, X_3):
        #print("starting ligeq1_run")
        #print(f"ligeq1: {X_3}")

        if self.edghk1 == 0 and self.edgcak != 0 and self.edgmgk != 0 and self.medium.Caf.getConcentration != 0 and self.medium.Caf.getConcentration != 0:
            ff = 1.0 + self.medium.Caf.get_concentration() / self.edgcak + self.medium.Mgf.get_concentration() / self.edgmgk

        elif self.edghk2 == 0 and self.edgcak != 0 and self.edgmgk != 0 and self.medium.Caf.getConcentration != 0 and self.medium.Caf.getConcentration != 0 and self.edghk1 != 0:
            ff = 1.0 + X_3 / self.edghk1 + self.medium.Caf.get_concentration() / self.edgcak + self.medium.Mgf.getConcentration() / self.edgmgk

        elif self.medium.Caf.getConcentration() == 0 and self.edghk1 != 0 and self.edghk2 != 0 and self.edgmgk != 0 and self.medium.Caf.getConcentration != 0 and self.medium.Caf.getConcentration != 0 and self.edghk1 != 0:
            ff = 1.0 + X_3 / self.edghk1 + (
                    X_3 ** 2 * self.edghk2) / self.edghk1 + self.medium.Mgf.getConcentration() / self.edgmgk

        elif self.medium.Mgf.getConcentration() == 0 and self.edghk2 != 0 and self.edgcak != 0 and self.edgmgk != 0 and self.medium.Caf.getConcentration != 0 and self.edghk1 != 0:
            ff = 1.0 + X_3 / self.edghk1 + (
                    X_3 ** 2 * self.edghk2) / self.edghk1 + self.medium.Caf.getConcentration() / self.edgcak

        elif self.edgcak == 0 and self.medium.Mgf.getConcentration() == 0 and self.edghk2 != 0 and self.edgmgk != 0 and self.medium.Caf.getConcentration != 0 and self.edghk1 != 0:
            ff = 1.0 + X_3 / self.edghk1 + (
                    X_3 ** 2 * self.edghk2) / self.edghk1 + self.medium.Mgf.getConcentration() / self.edgmgk

        elif self.edgcak == 0 and self.edghk2 == 0 and self.edgmgk == 0 and self.edghk1 == 0:
            ff = 1.0

        else:
            ff = (1.0 + X_3 / self.edghk1 + (
                    X_3 ** 2 * self.edghk2) / self.edghk1 + self.medium.Caf.getConcentration() / self.edgcak +
                  self.medium.Mgf.getConcentration() / self.edgmgk)

        if ff == 0 and self.edgcak == 0 and self.edghk2 == 0 and self.edgmgk == 0 and self.edghk1 == 0:
            y = (X_3 * (self.buffer_conc / (X_3 + self.A_5)) - self.lig_hb - self.A_8 * self.delta_H - self.dedgh)
        else:  #elif self.edgcak == 0 and self.edghk2 == 0 and self.edgmgk == 0 and self.edghk1 == 0:
            y = 1.0

        return y

    def ligeq2_run(self, X_3):
        #print(f"ligeq2: {X_3}")
        #print("starting ligeq2_run")
        if self.edghk1 == 0 or self.edghk2 == 0 or self.edgcak == 0 or self.edgmgk == 0:
            return 0

        self.ff = (1.0 + self.medium.H.get_concentration() / self.edghk1 +
                   (self.medium.H.get_concentration() ** 2) / (self.edghk1 * self.edghk2) +
                   X_3 / self.edgcak + self.medium.Mgf.get_concentration() / self.edgmgk)

        if self.ff == 0:
            return 0

        return self.medium.Cat.get_concentration() - X_3 * (1.0 + self.edgto / self.ff * self.edgcak)

    def ligeq3_run(self, X_3):
        #print(f"ligeq3: {X_3}")
        #print("starting ligeq3_run")
        if self.edghk1 == 0 or self.edghk2 == 0 or self.edgcak == 0 or self.edgmgk == 0:
            return 0

        self.ff = (1.0 + self.medium.H.get_concentration() / self.edghk1 +
                   (self.medium.H.get_concentration() ** 2) / (self.edghk1 * self.edghk2) +
                   self.medium.Caf.get_concentration() / self.edgcak +
                   X_3 / self.edgmgk)

        if self.ff == 0.0:
            return 0

        return (self.medium.Mgt.get_concentration() -
                X_3 * (1.0 + self.edgto / self.ff * self.edgmgk))

#rbc = RBC_model()
#eqca = rbc.Eqca(rbc)
#eqmg = rbc.Eqmg(rbc)

# Example call to newton_raphson (you'll need to provide appropriate parameters)
#result_ca = rbc.newton_raphson(eqca, 1.0, 0.1, 1e-6, 100, 0, True)
#result_mg = rbc.newton_raphson(eqmg, 1.0, 0.1, 1e-6, 100, 0, True)

#print(f"Result for Eqca: {result_ca}")
#print(f"Result for Eqmg: {result_mg}")
